package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.components.TournamentCard
import com.example.ui.theme.DarkZincBorder
import com.example.ui.theme.DarkZincSurface
import com.example.ui.theme.NeonLime
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun TournamentsScreen(viewModel: MainViewModel) {
    val tournaments by viewModel.tournaments.collectAsState()
    val joinedMatches by viewModel.joinedMatches.collectAsState()
    val currentFormatFilter by viewModel.tournamentFormatFilter.collectAsState()
    val searchQuery by viewModel.tournamentSearchQuery.collectAsState()

    val joinedIds = joinedMatches.map { it.tournamentId }.toSet()

    val filteredTournaments = tournaments.filter { t ->
        val matchesFormat = currentFormatFilter == "All" || t.format.equals(currentFormatFilter, ignoreCase = true)
        val matchesSearch = searchQuery.isBlank() ||
                t.title.contains(searchQuery, ignoreCase = true) ||
                t.mapName.contains(searchQuery, ignoreCase = true)
        matchesFormat && matchesSearch
    }

    val formats = listOf("All", "Solo", "Duo", "Squad")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PitchBlack)
            .padding(horizontal = 16.dp)
            .testTag("tournaments_screen_container"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        item {
            Text(
                text = "ALL TOURNAMENTS",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = TextPrimary
            )
            Text(
                text = "Select format and register your slot",
                fontSize = 12.sp,
                color = TextMuted
            )
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setTournamentSearchQuery(it) },
                placeholder = { Text("Search tournament name or map...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = NeonLime) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_tournaments_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonLime,
                    unfocusedBorderColor = DarkZincBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedPlaceholderColor = TextMuted,
                    unfocusedPlaceholderColor = TextMuted,
                    focusedContainerColor = DarkZincSurface,
                    unfocusedContainerColor = DarkZincSurface
                ),
                shape = RoundedCornerShape(10.dp),
                singleLine = true
            )
        }

        // Format Filter Chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                formats.forEach { format ->
                    val isSelected = currentFormatFilter.equals(format, ignoreCase = true)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) NeonLime else DarkZincSurface)
                            .border(1.dp, if (isSelected) NeonLime else DarkZincBorder, RoundedCornerShape(8.dp))
                            .clickable { viewModel.setTournamentFormatFilter(format) }
                            .padding(vertical = 10.dp)
                            .testTag("filter_chip_$format"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = format.uppercase(),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) PitchBlack else TextPrimary
                        )
                    }
                }
            }
        }

        if (filteredTournaments.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No tournaments found matching criteria.", color = TextMuted, fontSize = 14.sp)
                }
            }
        } else {
            items(filteredTournaments) { tournament ->
                TournamentCard(
                    tournament = tournament,
                    isAlreadyJoined = joinedIds.contains(tournament.id),
                    onJoinClick = { viewModel.openJoinModal(tournament) }
                )
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
