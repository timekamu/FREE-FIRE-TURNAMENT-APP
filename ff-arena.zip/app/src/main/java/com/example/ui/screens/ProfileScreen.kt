package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.theme.DarkZincBorder
import com.example.ui.theme.DarkZincSurface
import com.example.ui.theme.NeonLime
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.PrizeGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ProfileScreen(viewModel: MainViewModel) {
    val profile by viewModel.userProfile.collectAsState()

    val ign = profile?.ign ?: "SK_GAMER_99"
    val ffUid = profile?.ffUid ?: "8274910283"
    val matchesPlayed = profile?.matchesPlayed ?: 42
    val totalKills = profile?.totalKills ?: 188
    val totalEarnings = profile?.totalEarnings ?: 4850.0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PitchBlack)
            .padding(horizontal = 16.dp)
            .testTag("profile_screen_container"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        item {
            Text(
                text = "PLAYER PROFILE",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = TextPrimary
            )
            Text(
                text = "Manage in-game credentials and view career statistics",
                fontSize = 12.sp,
                color = TextMuted
            )
        }

        // PROFILE HEADER CARD
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, NeonLime.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                    .testTag("profile_info_card"),
                colors = CardDefaults.cardColors(containerColor = DarkZincSurface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .clip(CircleShape)
                            .border(3.dp, NeonLime, CircleShape)
                            .background(PitchBlack),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = ign.take(2).uppercase(),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = NeonLime
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = ign,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(PrizeGold)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("PRO", fontSize = 9.sp, fontWeight = FontWeight.Black, color = PitchBlack)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "FF UID: $ffUid",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted
                    )

                    val userPhone by viewModel.loggedInPhoneNumber.collectAsState()
                    if (userPhone.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "📱 Phone: $userPhone",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NeonLime
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.setShowEditProfileModal(true) },
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                                .testTag("btn_edit_profile"),
                            colors = ButtonDefaults.buttonColors(containerColor = DarkZincBorder, contentColor = NeonLime),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("EDIT PROFILE", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }

                        Button(
                            onClick = { viewModel.logout() },
                            modifier = Modifier
                                .weight(0.8f)
                                .height(42.dp)
                                .testTag("btn_logout_user"),
                            colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.LiveRed.copy(alpha = 0.2f), contentColor = com.example.ui.theme.LiveRed),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, com.example.ui.theme.LiveRed)
                        ) {
                            Text("LOG OUT", fontWeight = FontWeight.Black, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // PLAYER CAREER STATS GRID
        item {
            Text("CAREER STATISTICS", fontSize = 14.sp, fontWeight = FontWeight.Black, color = TextPrimary)
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ProfileStatCard(
                        title = "MATCHES PLAYED",
                        value = "$matchesPlayed",
                        icon = Icons.Default.SportsEsports,
                        color = NeonLime,
                        modifier = Modifier.weight(1f)
                    )
                    ProfileStatCard(
                        title = "TOTAL KILLS",
                        value = "$totalKills",
                        icon = Icons.Default.MilitaryTech,
                        color = PrizeGold,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ProfileStatCard(
                        title = "TOTAL EARNINGS",
                        value = "₹${totalEarnings.toInt()}",
                        icon = Icons.Default.EmojiEvents,
                        color = PrizeGold,
                        modifier = Modifier.weight(1f)
                    )
                    ProfileStatCard(
                        title = "WIN RATE",
                        value = "68%",
                        icon = Icons.Default.Star,
                        color = NeonLime,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // HELP & SUPPORT
        item {
            Text("SUPPORT & RULES", fontSize = 14.sp, fontWeight = FontWeight.Black, color = TextPrimary)
            Spacer(modifier = Modifier.height(8.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkZincSurface)
                    .border(1.dp, DarkZincBorder, RoundedCornerShape(12.dp))
            ) {
                SupportItem(title = "How to Join Custom Room Guide", icon = Icons.Default.HelpOutline)
                SupportItem(title = "Fair Play & Anti-Cheat Rules", icon = Icons.Default.Shield)
                SupportItem(title = "Customer Support 24/7 (WhatsApp)", icon = Icons.Default.SportsEsports)
            }
        }

        // ADMIN STAFF PORTAL
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, com.example.ui.theme.LiveRed.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .testTag("admin_portal_card"),
                colors = CardDefaults.cardColors(containerColor = DarkZincSurface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = com.example.ui.theme.LiveRed, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("ADMIN CONTROL PORTAL", fontSize = 13.sp, fontWeight = FontWeight.Black, color = TextPrimary)
                            Text("Tournament creation & payment approvals", fontSize = 10.sp, color = TextMuted)
                        }
                    }

                    Button(
                        onClick = { viewModel.setShowAdminLoginModal(true) },
                        colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.LiveRed, contentColor = TextPrimary),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("LOGIN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun ProfileStatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(DarkZincSurface)
            .border(1.dp, DarkZincBorder, RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(title, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextMuted)
            Text(value, fontSize = 16.sp, fontWeight = FontWeight.Black, color = TextPrimary)
        }
    }
}

@Composable
private fun SupportItem(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, tint = NeonLime, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted)
    }
}
