package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppTab
import com.example.ui.theme.DarkZincBorder
import com.example.ui.theme.DarkZincSurface
import com.example.ui.theme.NeonLime
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

private data class NavItemData(
    val tab: AppTab,
    val title: String,
    val icon: ImageVector,
    val testTag: String
)

@Composable
fun BottomNavBar(
    currentTab: AppTab,
    onTabSelected: (AppTab) -> Unit
) {
    val items = listOf(
        NavItemData(AppTab.HOME, "Home", Icons.Default.Home, "nav_tab_home"),
        NavItemData(AppTab.TOURNAMENTS, "Tournaments", Icons.Default.EmojiEvents, "nav_tab_tournaments"),
        NavItemData(AppTab.MY_MATCHES, "My Matches", Icons.Default.SportsEsports, "nav_tab_my_matches"),
        NavItemData(AppTab.WALLET, "Wallet", Icons.Default.AccountBalanceWallet, "nav_tab_wallet"),
        NavItemData(AppTab.PROFILE, "Profile", Icons.Default.Person, "nav_tab_profile")
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkZincSurface)
            .border(width = 1.dp, color = DarkZincBorder)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(vertical = 8.dp, horizontal = 4.dp)
            .testTag("bottom_nav_bar"),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { item ->
            val isSelected = currentTab == item.tab
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onTabSelected(item.tab) }
                    .padding(horizontal = 8.dp, vertical = 6.dp)
                    .testTag(item.testTag)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = if (isSelected) {
                        Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(NeonLime.copy(alpha = 0.2f))
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    } else Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.title,
                        tint = if (isSelected) NeonLime else TextMuted,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Text(
                    text = item.title,
                    fontSize = 11.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) TextPrimary else TextMuted,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
    }
}
