package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.NotificationEntity
import com.example.data.local.PaymentSettingsEntity
import com.example.data.local.UserProfileEntity
import com.example.ui.theme.DarkZincBorder
import com.example.ui.theme.DarkZincSurface
import com.example.ui.theme.DarkZincSurfaceVariant
import com.example.ui.theme.DiamondBlue
import com.example.ui.theme.LiveRed
import com.example.ui.theme.NeonLime
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.PrizeGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun QrCodeGraphic(
    qrImageUrl: String = "",
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(PitchBlack, RoundedCornerShape(12.dp))
            .border(1.dp, NeonLime, RoundedCornerShape(12.dp))
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (qrImageUrl.isNotBlank()) {
                coil.compose.AsyncImage(
                    model = qrImageUrl,
                    contentDescription = "Admin Payment QR Code",
                    modifier = Modifier
                        .size(130.dp)
                        .clip(RoundedCornerShape(8.dp))
                )
            } else {
                Icon(
                    imageVector = Icons.Default.QrCodeScanner,
                    contentDescription = "Admin Payment QR Code",
                    tint = NeonLime,
                    modifier = Modifier.size(110.dp)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text("SCAN TO PAY (GPay / PhonePe / Paytm / bKash)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        }
    }
}

@Composable
fun AddMoneyModal(
    paymentSettings: PaymentSettingsEntity? = null,
    onDismiss: () -> Unit,
    onConfirmAddMoney: (amount: Double, utrNumber: String) -> Unit
) {
    var amountInput by remember { mutableStateOf("100") }
    var utrInput by remember { mutableStateOf("") }
    val presets = listOf(50.0, 100.0, 500.0, 1000.0)
    val adminUpiId = paymentSettings?.upiOrNumber?.ifBlank { "ffarena.admin@upi" } ?: "ffarena.admin@upi"
    val instructions = paymentSettings?.instructions?.ifBlank { "Pay using QR or UPI Number and enter UTR/Ref No." }
        ?: "Pay using QR or UPI Number and enter UTR/Ref No."

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, NeonLime.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .testTag("add_money_modal"),
            colors = CardDefaults.cardColors(containerColor = DarkZincSurface)
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DEPOSIT MONEY (QR / UPI)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        color = NeonLime
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // QR Code Display Card
                QrCodeGraphic(qrImageUrl = paymentSettings?.qrImageUrl ?: "", modifier = Modifier.fillMaxWidth())

                Spacer(modifier = Modifier.height(10.dp))

                // Admin UPI ID Card with Copy action
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(PitchBlack)
                        .border(1.dp, DarkZincBorder, RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("PAYMENT UPI / NUMBER", fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                        Text(adminUpiId, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = NeonLime)
                    }
                    IconButton(onClick = { /* Copied */ }, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy UPI ID", tint = NeonLime, modifier = Modifier.size(18.dp))
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(instructions, fontSize = 10.sp, color = TextMuted)

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    presets.forEach { preset ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (amountInput == preset.toInt().toString()) NeonLime else PitchBlack)
                                .border(1.dp, DarkZincBorder, RoundedCornerShape(6.dp))
                                .clickable { amountInput = preset.toInt().toString() }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "₹${preset.toInt()}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (amountInput == preset.toInt().toString()) PitchBlack else TextPrimary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { amountInput = it },
                        label = { Text("Amount Paid (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("add_money_amount_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonLime,
                            unfocusedBorderColor = DarkZincBorder,
                            focusedLabelColor = NeonLime,
                            unfocusedLabelColor = TextMuted,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = PitchBlack,
                            unfocusedContainerColor = PitchBlack
                        ),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = utrInput,
                        onValueChange = { utrInput = it },
                        label = { Text("UTR / Ref No.") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("add_money_utr_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonLime,
                            unfocusedBorderColor = DarkZincBorder,
                            focusedLabelColor = NeonLime,
                            unfocusedLabelColor = TextMuted,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = PitchBlack,
                            unfocusedContainerColor = PitchBlack
                        ),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        val amount = amountInput.toDoubleOrNull() ?: 0.0
                        onConfirmAddMoney(amount, utrInput)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("confirm_add_money_btn"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonLime, contentColor = PitchBlack)
                ) {
                    Text("SUBMIT DEPOSIT FOR APPROVAL", fontWeight = FontWeight.Black, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun InsufficientBalanceModal(
    onDismiss: () -> Unit,
    onOpenWallet: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, LiveRed, RoundedCornerShape(16.dp))
                .testTag("insufficient_balance_modal"),
            colors = CardDefaults.cardColors(containerColor = DarkZincSurface)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "INSUFFICIENT BALANCE",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        color = LiveRed
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Insufficient Wallet Balance! Please add money to your wallet to join this tournament.",
                    fontSize = 13.sp,
                    color = TextPrimary
                )

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = {
                        onDismiss()
                        onOpenWallet()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("open_wallet_add_money_btn"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonLime, contentColor = PitchBlack)
                ) {
                    Text("OPEN WALLET / ADD MONEY", fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
fun WithdrawModal(
    currentBalance: Double,
    onDismiss: () -> Unit,
    onConfirmWithdraw: (amount: Double, upiId: String) -> Unit
) {
    var amountInput by remember { mutableStateOf("100") }
    var upiInput by remember { mutableStateOf("user@upi") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, PrizeGold.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .testTag("withdraw_modal"),
            colors = CardDefaults.cardColors(containerColor = DarkZincSurface)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "WITHDRAW WINNINGS",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = PrizeGold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Text(
                    text = "Available Balance: ₹${String.format("%.2f", currentBalance)}",
                    fontSize = 12.sp,
                    color = TextMuted
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = upiInput,
                    onValueChange = { upiInput = it },
                    label = { Text("UPI ID (GPay / PhonePe / Paytm)") },
                    leadingIcon = { Icon(Icons.Default.Payment, contentDescription = null, tint = PrizeGold) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("withdraw_upi_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrizeGold,
                        unfocusedBorderColor = DarkZincBorder,
                        focusedLabelColor = PrizeGold,
                        unfocusedLabelColor = TextMuted,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = PitchBlack,
                        unfocusedContainerColor = PitchBlack
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("Withdrawal Amount (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("withdraw_amount_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrizeGold,
                        unfocusedBorderColor = DarkZincBorder,
                        focusedLabelColor = PrizeGold,
                        unfocusedLabelColor = TextMuted,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = PitchBlack,
                        unfocusedContainerColor = PitchBlack
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = {
                        val amount = amountInput.toDoubleOrNull() ?: 0.0
                        onConfirmWithdraw(amount, upiInput)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("confirm_withdraw_btn"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrizeGold, contentColor = PitchBlack)
                ) {
                    Text("SUBMIT WITHDRAWAL REQUEST", fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
fun EditProfileModal(
    userProfile: UserProfileEntity?,
    onDismiss: () -> Unit,
    onSaveProfile: (ign: String, ffUid: String) -> Unit
) {
    var ign by remember(userProfile) { mutableStateOf(userProfile?.ign ?: "") }
    var ffUid by remember(userProfile) { mutableStateOf(userProfile?.ffUid ?: "") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, NeonLime.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .testTag("edit_profile_modal"),
            colors = CardDefaults.cardColors(containerColor = DarkZincSurface)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "EDIT PLAYER PROFILE",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = NeonLime
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = ign,
                    onValueChange = { ign = it },
                    label = { Text("In-Game Name (IGN)") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = NeonLime) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_ign_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonLime,
                        unfocusedBorderColor = DarkZincBorder,
                        focusedLabelColor = NeonLime,
                        unfocusedLabelColor = TextMuted,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = PitchBlack,
                        unfocusedContainerColor = PitchBlack
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = ffUid,
                    onValueChange = { ffUid = it },
                    label = { Text("Free Fire UID") },
                    leadingIcon = { Icon(Icons.Default.SportsEsports, contentDescription = null, tint = NeonLime) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_ff_uid_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonLime,
                        unfocusedBorderColor = DarkZincBorder,
                        focusedLabelColor = NeonLime,
                        unfocusedLabelColor = TextMuted,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = PitchBlack,
                        unfocusedContainerColor = PitchBlack
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = { onSaveProfile(ign, ffUid) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_profile_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonLime, contentColor = PitchBlack)
                ) {
                    Text("SAVE PROFILE DETAILS", fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
fun BuyDiamondsModal(
    onDismiss: () -> Unit,
    onBuy: (rupees: Double, diamonds: Int) -> Unit
) {
    data class DiamondPack(val diamonds: Int, val priceRupees: Double, val bonus: String)

    val packs = listOf(
        DiamondPack(50, 40.0, "+5 Bonus"),
        DiamondPack(120, 90.0, "+15 Bonus"),
        DiamondPack(310, 240.0, "+40 Bonus"),
        DiamondPack(520, 400.0, "+70 Bonus")
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, DiamondBlue.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .testTag("buy_diamonds_modal"),
            colors = CardDefaults.cardColors(containerColor = DarkZincSurface)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DIAMOND STORE",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = DiamondBlue
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Text("Instant Diamond Top-Up with Wallet Balance", fontSize = 11.sp, color = TextMuted)

                Spacer(modifier = Modifier.height(14.dp))

                packs.forEach { pack ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(PitchBlack)
                            .border(1.dp, DarkZincBorder, RoundedCornerShape(10.dp))
                            .clickable { onBuy(pack.priceRupees, pack.diamonds) }
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Diamond, contentDescription = null, tint = DiamondBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("${pack.diamonds} Diamonds", fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text(pack.bonus, fontSize = 10.sp, color = NeonLime)
                            }
                        }

                        Button(
                            onClick = { onBuy(pack.priceRupees, pack.diamonds) },
                            colors = ButtonDefaults.buttonColors(containerColor = DiamondBlue, contentColor = PitchBlack),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("₹${pack.priceRupees.toInt()}", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NotificationsSheet(
    notifications: List<NotificationEntity>,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, DarkZincBorder, RoundedCornerShape(16.dp))
                .testTag("notifications_modal"),
            colors = CardDefaults.cardColors(containerColor = DarkZincSurface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Notifications, contentDescription = null, tint = NeonLime)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("NOTIFICATIONS", fontSize = 16.sp, fontWeight = FontWeight.Black, color = TextPrimary)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (notifications.isEmpty()) {
                    Text("No notifications yet.", color = TextMuted, modifier = Modifier.padding(vertical = 16.dp))
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.height(300.dp)
                    ) {
                        items(notifications) { notif ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(PitchBlack)
                                    .padding(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(notif.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = NeonLime)
                                    Text(notif.timeAgo, fontSize = 10.sp, color = TextMuted)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(notif.message, fontSize = 12.sp, color = TextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }
}
