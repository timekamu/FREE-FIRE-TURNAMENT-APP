package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val EsportsDarkColorScheme = darkColorScheme(
    primary = NeonLime,
    onPrimary = PitchBlack,
    primaryContainer = NeonLimeDark,
    onPrimaryContainer = TextPrimary,
    secondary = PrizeGold,
    onSecondary = PitchBlack,
    tertiary = DiamondBlue,
    onTertiary = PitchBlack,
    background = DarkZincBg,
    onBackground = TextPrimary,
    surface = DarkZincSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkZincSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DarkZincBorder,
    error = LiveRed
)

@Composable
fun FFArenaTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = EsportsDarkColorScheme,
        typography = Typography,
        content = content
    )
}
