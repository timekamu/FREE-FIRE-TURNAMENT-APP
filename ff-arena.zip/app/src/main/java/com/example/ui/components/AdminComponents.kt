package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.DepositRequestEntity
import com.example.data.local.PaymentSettingsEntity
import com.example.data.local.TournamentEntity
import com.example.data.local.UserProfileEntity
import com.example.ui.theme.DarkZincBorder
import com.example.ui.theme.DarkZincSurface
import com.example.ui.theme.DarkZincSurfaceVariant
import com.example.ui.theme.LiveRed
import com.example.ui.theme.NeonLime
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.PrizeGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AdminLoginModal(
    onDismiss: () -> Unit,
    onVerifyPin: (String) -> Unit
) {
    var pinInput by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, LiveRed, RoundedCornerShape(16.dp))
                .testTag("admin_login_modal"),
            colors = CardDefaults.cardColors(containerColor = DarkZincSurface)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = LiveRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("ADMIN PORTAL LOGIN", fontSize = 16.sp, fontWeight = FontWeight.Black, color = TextPrimary)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text("Protected Staff Area. Enter Admin Secret PIN ('0066'):", fontSize = 12.sp, color = TextMuted)

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = pinInput,
                    onValueChange = {
                        pinInput = it
                        isError = false
                    },
                    label = { Text("4-Digit Admin PIN") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = LiveRed) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    isError = isError,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_pin_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LiveRed,
                        unfocusedBorderColor = DarkZincBorder,
                        focusedLabelColor = LiveRed,
                        unfocusedLabelColor = TextMuted,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = PitchBlack,
                        unfocusedContainerColor = PitchBlack
                    ),
                    singleLine = true
                )

                if (isError) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Invalid Admin PIN! Please try again.", fontSize = 11.sp, color = LiveRed, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = {
                        if (pinInput.trim() == "0066") {
                            onVerifyPin(pinInput)
                        } else {
                            isError = true
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("verify_admin_pin_btn"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = LiveRed, contentColor = TextPrimary)
                ) {
                    Text("UNLOCK ADMIN PANEL", fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
fun AdminPanelModal(
    tournaments: List<TournamentEntity>,
    depositRequests: List<DepositRequestEntity>,
    allUsers: List<UserProfileEntity> = emptyList(),
    paymentSettings: PaymentSettingsEntity? = null,
    onDismiss: () -> Unit,
    onCreateTournament: (
        title: String,
        format: String,
        entryFeeDiamonds: Int,
        prizePool: Double,
        maxSlots: Int,
        mapName: String,
        dateTimeString: String,
        roomId: String,
        roomPassword: String
    ) -> Unit,
    onUpdateRoomCredentials: (tournamentId: String, roomId: String, roomPassword: String) -> Unit,
    onApproveDeposit: (DepositRequestEntity) -> Unit,
    onRejectDeposit: (DepositRequestEntity) -> Unit,
    onSavePaymentSettings: (qrImageUrl: String, upiOrNumber: String, instructions: String) -> Unit = { _, _, _ -> },
    onDeclareWinner: (tournamentId: String, winnerPhoneNumber: String, prizeAmount: Double) -> Unit = { _, _, _ -> }
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Create, 1: Room, 2: Deposits, 3: Players, 4: Payment, 5: Winner

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, LiveRed.copy(alpha = 0.8f), RoundedCornerShape(16.dp))
                .testTag("admin_panel_modal"),
            colors = CardDefaults.cardColors(containerColor = DarkZincSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(LiveRed)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("ADMIN", fontSize = 10.sp, fontWeight = FontWeight.Black, color = TextPrimary)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("FF ARENA CONTROL PANEL", fontSize = 16.sp, fontWeight = FontWeight.Black, color = TextPrimary)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Navigation Tabs
                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(PitchBlack)
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            val tabs = listOf(
                                "CREATE",
                                "ROOM ID",
                                "DEPOSITS (${depositRequests.count { it.status == "PENDING" }})",
                                "PLAYERS (${allUsers.size})",
                                "PAYMENT",
                                "WINNER"
                            )
                            tabs.forEachIndexed { index, title ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (selectedTab == index) LiveRed else PitchBlack)
                                        .clickable { selectedTab = index }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = title,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (selectedTab == index) TextPrimary else TextMuted,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Tab Content
                when (selectedTab) {
                    0 -> CreateMatchTab(onCreateTournament)
                    1 -> RoomCredentialsTab(tournaments, onUpdateRoomCredentials)
                    2 -> PendingDepositsTab(depositRequests, onApproveDeposit, onRejectDeposit)
                    3 -> RegisteredPlayersTab(allUsers)
                    4 -> PaymentSettingsTab(paymentSettings, onSavePaymentSettings)
                    5 -> DeclareWinnerTab(tournaments, allUsers, onDeclareWinner)
                }
            }
        }
    }
}

@Composable
fun CreateMatchTab(
    onCreateTournament: (
        title: String,
        format: String,
        entryFeeDiamonds: Int,
        prizePool: Double,
        maxSlots: Int,
        mapName: String,
        dateTimeString: String,
        roomId: String,
        roomPassword: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var format by remember { mutableStateOf("Squad") }
    var entryFeeInput by remember { mutableStateOf("50") }
    var prizePoolInput by remember { mutableStateOf("10000") }
    var maxSlotsInput by remember { mutableStateOf("48") }
    var mapName by remember { mutableStateOf("Bermuda") }
    var dateTimeString by remember { mutableStateOf("Today, 9:00 PM") }
    var roomId by remember { mutableStateOf("") }
    var roomPassword by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Tournament Basic Details", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NeonLime)
            Spacer(modifier = Modifier.height(4.dp))

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Tournament Title") },
                modifier = Modifier.fillMaxWidth(),
                colors = adminTextFieldColors(),
                singleLine = true
            )
        }

        item {
            Text("Match Format", fontSize = 11.sp, color = TextMuted)
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Solo", "Duo", "Squad").forEach { fmt ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (format == fmt) NeonLime else PitchBlack)
                            .border(1.dp, DarkZincBorder, RoundedCornerShape(6.dp))
                            .clickable { format = fmt }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(fmt, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (format == fmt) PitchBlack else TextPrimary)
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = entryFeeInput,
                    onValueChange = { entryFeeInput = it },
                    label = { Text("Entry Fee (Diamonds)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    colors = adminTextFieldColors(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = prizePoolInput,
                    onValueChange = { prizePoolInput = it },
                    label = { Text("Prize Pool (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    colors = adminTextFieldColors(),
                    singleLine = true
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = maxSlotsInput,
                    onValueChange = { maxSlotsInput = it },
                    label = { Text("Total Slots") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                    colors = adminTextFieldColors(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = mapName,
                    onValueChange = { mapName = it },
                    label = { Text("Map Name") },
                    modifier = Modifier.weight(1f),
                    colors = adminTextFieldColors(),
                    singleLine = true
                )
            }
        }

        item {
            OutlinedTextField(
                value = dateTimeString,
                onValueChange = { dateTimeString = it },
                label = { Text("Match Time / Date") },
                modifier = Modifier.fillMaxWidth(),
                colors = adminTextFieldColors(),
                singleLine = true
            )
        }

        item {
            Text("Initial Room Credentials (Optional)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PrizeGold)
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = roomId,
                    onValueChange = { roomId = it },
                    label = { Text("Room ID") },
                    modifier = Modifier.weight(1f),
                    colors = adminTextFieldColors(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = roomPassword,
                    onValueChange = { roomPassword = it },
                    label = { Text("Room Pass") },
                    modifier = Modifier.weight(1f),
                    colors = adminTextFieldColors(),
                    singleLine = true
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = {
                    onCreateTournament(
                        title,
                        format,
                        entryFeeInput.toIntOrNull() ?: 0,
                        prizePoolInput.toDoubleOrNull() ?: 0.0,
                        maxSlotsInput.toIntOrNull() ?: 48,
                        mapName,
                        dateTimeString,
                        roomId,
                        roomPassword
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("publish_tournament_btn"),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NeonLime, contentColor = PitchBlack)
            ) {
                Icon(Icons.Default.AddCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("PUBLISH TOURNAMENT MATCH", fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
fun RoomCredentialsTab(
    tournaments: List<TournamentEntity>,
    onUpdateRoomCredentials: (tournamentId: String, roomId: String, roomPassword: String) -> Unit
) {
    var selectedTournamentId by remember(tournaments) { mutableStateOf(tournaments.firstOrNull()?.id ?: "") }
    val selectedTournament = tournaments.find { it.id == selectedTournamentId }

    var roomIdInput by remember(selectedTournamentId) { mutableStateOf(selectedTournament?.roomId ?: "") }
    var roomPasswordInput by remember(selectedTournamentId) { mutableStateOf(selectedTournament?.roomPassword ?: "") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Select Active Match to Release Room Credentials:", fontSize = 12.sp, color = TextMuted)

        LazyColumn(
            modifier = Modifier.height(140.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(tournaments) { tourney ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selectedTournamentId == tourney.id) DarkZincSurfaceVariant else PitchBlack)
                        .border(
                            1.dp,
                            if (selectedTournamentId == tourney.id) NeonLime else DarkZincBorder,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable {
                            selectedTournamentId = tourney.id
                            roomIdInput = tourney.roomId ?: ""
                            roomPasswordInput = tourney.roomPassword ?: ""
                        }
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(tourney.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                        Text("${tourney.format} | ${tourney.dateTimeString}", fontSize = 10.sp, color = TextMuted)
                    }
                    Text(tourney.status, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (tourney.status == "LIVE") LiveRed else NeonLime)
                }
            }
        }

        if (selectedTournament != null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PitchBlack, RoundedCornerShape(10.dp))
                    .padding(12.dp),
                colors = CardDefaults.cardColors(containerColor = PitchBlack)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Set Credentials for '${selectedTournament.title}':", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = PrizeGold)

                    OutlinedTextField(
                        value = roomIdInput,
                        onValueChange = { roomIdInput = it },
                        label = { Text("Room ID") },
                        leadingIcon = { Icon(Icons.Default.VpnKey, contentDescription = null, tint = PrizeGold) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = adminTextFieldColors(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = roomPasswordInput,
                        onValueChange = { roomPasswordInput = it },
                        label = { Text("Room Password") },
                        leadingIcon = { Icon(Icons.Default.Key, contentDescription = null, tint = PrizeGold) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = adminTextFieldColors(),
                        singleLine = true
                    )

                    Button(
                        onClick = {
                            onUpdateRoomCredentials(selectedTournamentId, roomIdInput, roomPasswordInput)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("update_room_credentials_btn"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrizeGold, contentColor = PitchBlack)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("UPDATE & NOTIFY PLAYERS", fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }
}

@Composable
fun PendingDepositsTab(
    depositRequests: List<DepositRequestEntity>,
    onApproveDeposit: (DepositRequestEntity) -> Unit,
    onRejectDeposit: (DepositRequestEntity) -> Unit
) {
    if (depositRequests.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(30.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("No user deposit requests submitted yet.", color = TextMuted, fontSize = 13.sp)
        }
    } else {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(depositRequests) { req ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = PitchBlack),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkZincBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("User: ${req.userName}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                                if (req.userPhoneNumber.isNotBlank()) {
                                    Text("Phone: ${req.userPhoneNumber} | UID: ${req.ffUid.ifBlank { "N/A" }}", fontSize = 10.sp, color = TextMuted)
                                }
                                Text("UTR / Ref: ${req.utrNumber}", fontSize = 11.sp, color = NeonLime, fontWeight = FontWeight.SemiBold)
                            }

                            Text(
                                text = "₹${String.format("%.2f", req.amount)}",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = PrizeGold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Status: ${req.status}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = when(req.status) {
                                "APPROVED" -> NeonLime
                                "REJECTED" -> LiveRed
                                else -> PrizeGold
                            })

                            if (req.status == "PENDING") {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Button(
                                        onClick = { onRejectDeposit(req) },
                                        colors = ButtonDefaults.buttonColors(containerColor = LiveRed, contentColor = TextPrimary),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Text("REJECT", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = { onApproveDeposit(req) },
                                        colors = ButtonDefaults.buttonColors(containerColor = NeonLime, contentColor = PitchBlack),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Text("APPROVE", fontSize = 11.sp, fontWeight = FontWeight.Black)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RegisteredPlayersTab(users: List<UserProfileEntity>) {
    if (users.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(30.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("No registered player accounts found.", color = TextMuted, fontSize = 13.sp)
        }
    } else {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(users) { user ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = PitchBlack),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkZincBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(user.ign, fontWeight = FontWeight.Black, fontSize = 14.sp, color = NeonLime)
                                Text("Phone: ${user.phoneNumber}", fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                Text("FF UID: ${user.ffUid}", fontSize = 10.sp, color = TextMuted)
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text("₹${String.format("%.2f", user.rupeesBalance)}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PrizeGold)
                                Text("💎 ${user.diamondsBalance}", fontSize = 11.sp, color = TextSecondary)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Matches: ${user.matchesPlayed}", fontSize = 10.sp, color = TextMuted)
                            Text("Kills: ${user.totalKills}", fontSize = 10.sp, color = TextMuted)
                            Text("Earnings: ₹${user.totalEarnings.toInt()}", fontSize = 10.sp, color = TextMuted)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PaymentSettingsTab(
    currentSettings: PaymentSettingsEntity?,
    onSavePaymentSettings: (qrImageUrl: String, upiOrNumber: String, instructions: String) -> Unit
) {
    var qrUrlInput by remember(currentSettings) { mutableStateOf(currentSettings?.qrImageUrl ?: "") }
    var upiOrNumberInput by remember(currentSettings) { mutableStateOf(currentSettings?.upiOrNumber ?: "") }
    var instructionsInput by remember(currentSettings) { mutableStateOf(currentSettings?.instructions ?: "") }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Admin Payment & Deposit Settings", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NeonLime)
            Text("Set QR Code image URL, UPI/Phone Number, and payment instructions shown to users in the Add Money modal.", fontSize = 10.sp, color = TextMuted)
            Spacer(modifier = Modifier.height(4.dp))
        }

        item {
            OutlinedTextField(
                value = qrUrlInput,
                onValueChange = { qrUrlInput = it },
                label = { Text("Payment QR Code Image Link") },
                placeholder = { Text("e.g. https://i.imgur.com/example_qr.png") },
                modifier = Modifier.fillMaxWidth(),
                colors = adminTextFieldColors(),
                singleLine = true
            )
        }

        item {
            OutlinedTextField(
                value = upiOrNumberInput,
                onValueChange = { upiOrNumberInput = it },
                label = { Text("Payment UPI ID / bKash / Nagad Number") },
                placeholder = { Text("e.g. 9876543210@upi") },
                modifier = Modifier.fillMaxWidth(),
                colors = adminTextFieldColors(),
                singleLine = true
            )
        }

        item {
            OutlinedTextField(
                value = instructionsInput,
                onValueChange = { instructionsInput = it },
                label = { Text("Payment Instructions") },
                modifier = Modifier.fillMaxWidth(),
                colors = adminTextFieldColors(),
                minLines = 2,
                maxLines = 4
            )
        }

        item {
            Spacer(modifier = Modifier.height(6.dp))
            Button(
                onClick = {
                    onSavePaymentSettings(qrUrlInput, upiOrNumberInput, instructionsInput)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_payment_settings_btn"),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NeonLime, contentColor = PitchBlack)
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("SAVE PAYMENT SETTINGS", fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
fun DeclareWinnerTab(
    tournaments: List<TournamentEntity>,
    allUsers: List<UserProfileEntity>,
    onDeclareWinner: (tournamentId: String, winnerPhoneNumber: String, prizeAmount: Double) -> Unit
) {
    var selectedTournamentId by remember(tournaments) { mutableStateOf(tournaments.firstOrNull()?.id ?: "") }
    val selectedTournament = tournaments.find { it.id == selectedTournamentId }

    var selectedWinnerPhone by remember { mutableStateOf(allUsers.firstOrNull()?.phoneNumber ?: "") }
    var prizeAmountInput by remember(selectedTournament) { mutableStateOf(selectedTournament?.prizePool?.toInt()?.toString() ?: "90") }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Select Tournament Match:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PrizeGold)
            Spacer(modifier = Modifier.height(4.dp))

            LazyColumn(
                modifier = Modifier.height(110.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(tournaments) { tourney ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selectedTournamentId == tourney.id) DarkZincSurfaceVariant else PitchBlack)
                            .border(
                                1.dp,
                                if (selectedTournamentId == tourney.id) PrizeGold else DarkZincBorder,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable {
                                selectedTournamentId = tourney.id
                                prizeAmountInput = tourney.prizePool.toInt().toString()
                            }
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(tourney.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                            Text("${tourney.format} | Prize: ₹${tourney.prizePool.toInt()}", fontSize = 10.sp, color = TextMuted)
                        }
                        Text(tourney.status, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (tourney.status == "COMPLETED") TextMuted else PrizeGold)
                    }
                }
            }
        }

        if (selectedTournament != null) {
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text("Select Winning Player:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NeonLime)
                Spacer(modifier = Modifier.height(4.dp))

                LazyColumn(
                    modifier = Modifier.height(120.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(allUsers) { user ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selectedWinnerPhone == user.phoneNumber) DarkZincSurfaceVariant else PitchBlack)
                                .border(
                                    1.dp,
                                    if (selectedWinnerPhone == user.phoneNumber) NeonLime else DarkZincBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedWinnerPhone = user.phoneNumber }
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(user.ign, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                                Text("Phone: ${user.phoneNumber} | UID: ${user.ffUid}", fontSize = 10.sp, color = TextMuted)
                            }
                            if (selectedWinnerPhone == user.phoneNumber) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NeonLime)
                            }
                        }
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = prizeAmountInput,
                    onValueChange = { prizeAmountInput = it },
                    label = { Text("Prize Amount (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    colors = adminTextFieldColors(),
                    singleLine = true
                )
            }

            item {
                Button(
                    onClick = {
                        val prize = prizeAmountInput.toDoubleOrNull() ?: selectedTournament.prizePool
                        onDeclareWinner(selectedTournamentId, selectedWinnerPhone, prize)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("declare_winner_btn"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrizeGold, contentColor = PitchBlack)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("DECLARE WINNER & CREDIT ₹$prizeAmountInput", fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
private fun adminTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = NeonLime,
    unfocusedBorderColor = DarkZincBorder,
    focusedLabelColor = NeonLime,
    unfocusedLabelColor = TextMuted,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    focusedContainerColor = PitchBlack,
    unfocusedContainerColor = PitchBlack
)
