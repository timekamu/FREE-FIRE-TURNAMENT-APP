package com.example.ui.screens

import androidx.compose.animation.core.InfiniteRepeatableSpec
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.JoinedMatchEntity
import com.example.data.local.TournamentEntity
import com.example.ui.AppTab
import com.example.ui.MainViewModel
import com.example.ui.components.TournamentCard
import com.example.ui.theme.DarkZincBorder
import com.example.ui.theme.DarkZincSurface
import com.example.ui.theme.DarkZincSurfaceVariant
import com.example.ui.theme.LiveRed
import com.example.ui.theme.NeonLime
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.PrizeGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToTournaments: () -> Unit
) {
    val tournaments by viewModel.tournaments.collectAsState()
    val joinedMatches by viewModel.joinedMatches.collectAsState()

    val liveTournament = tournaments.find { it.status == "LIVE" }
    val upcomingTournaments = tournaments.filter { it.status == "UPCOMING" }

    val joinedTournamentIds = joinedMatches.map { it.tournamentId }.toSet()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PitchBlack)
            .padding(horizontal = 16.dp)
            .testTag("home_screen_container"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        // 1. HERO BANNER
        item {
            HeroBanner(onExploreClick = onNavigateToTournaments)
        }

        // 2. QUICK STATS GRID (4 items)
        item {
            QuickStatsGrid()
        }

        // 3. LIVE NOW SECTION
        if (liveTournament != null) {
            item {
                SectionTitle(title = "LIVE NOW", badgeColor = LiveRed)
                Spacer(modifier = Modifier.height(8.dp))
                LiveMatchCard(
                    tournament = liveTournament,
                    isJoined = joinedTournamentIds.contains(liveTournament.id),
                    onJoinClick = { viewModel.openJoinModal(liveTournament) }
                )
            }
        }

        // 4. UPCOMING TOURNAMENTS LIST
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionTitle(title = "UPCOMING TOURNAMENTS", badgeColor = NeonLime)
                Button(
                    onClick = onNavigateToTournaments,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = NeonLime)
                ) {
                    Text("View All", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Icon(Icons.Default.ChevronRight, contentDescription = null, modifier = Modifier.size(16.dp))
                }
            }
        }

        items(upcomingTournaments) { tournament ->
            TournamentCard(
                tournament = tournament,
                isAlreadyJoined = joinedTournamentIds.contains(tournament.id),
                onJoinClick = { viewModel.openJoinModal(tournament) }
            )
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun HeroBanner(onExploreClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, DarkZincBorder, RoundedCornerShape(16.dp))
            .testTag("hero_banner"),
        colors = CardDefaults.cardColors(containerColor = DarkZincSurface)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            NeonLime.copy(alpha = 0.25f),
                            DarkZincSurface,
                            PitchBlack
                        ),
                        radius = 800f
                    )
                )
                .padding(20.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(NeonLime)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "OFFICIAL TOURNAMENT",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            color = PitchBlack
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "BATTLE. WIN.\nDOMINATE.",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    color = TextPrimary,
                    lineHeight = 30.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Join exciting Free Fire tournaments, climb ranks, and win real cash rewards!",
                    fontSize = 12.sp,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onExploreClick,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonLime, contentColor = PitchBlack),
                    modifier = Modifier.testTag("explore_tournaments_hero_btn")
                ) {
                    Icon(Icons.Default.SportsEsports, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("EXPLORE TOURNAMENTS", fontWeight = FontWeight.Black, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun QuickStatsGrid() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("quick_stats_grid"),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatCard(
            title = "LIVE",
            value = "12",
            icon = Icons.Default.PlayCircle,
            accentColor = LiveRed,
            modifier = Modifier.weight(1f)
        )
        StatCard(
            title = "UPCOMING",
            value = "28",
            icon = Icons.Default.HourglassTop,
            accentColor = NeonLime,
            modifier = Modifier.weight(1f)
        )
        StatCard(
            title = "PLAYERS",
            value = "15.6K",
            icon = Icons.Default.People,
            accentColor = TextPrimary,
            modifier = Modifier.weight(1f)
        )
        StatCard(
            title = "PRIZE POOL",
            value = "₹3.2L",
            icon = Icons.Default.EmojiEvents,
            accentColor = PrizeGold,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(DarkZincSurface)
            .border(1.dp, DarkZincBorder, RoundedCornerShape(10.dp))
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(imageVector = icon, contentDescription = title, tint = accentColor, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = value, fontSize = 15.sp, fontWeight = FontWeight.Black, color = TextPrimary)
        Text(text = title, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextMuted)
    }
}

@Composable
private fun SectionTitle(title: String, badgeColor: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(badgeColor)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            fontSize = 15.sp,
            fontWeight = FontWeight.Black,
            color = TextPrimary,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
private fun LiveMatchCard(
    tournament: TournamentEntity,
    isJoined: Boolean,
    onJoinClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, LiveRed.copy(alpha = 0.8f), RoundedCornerShape(14.dp))
            .testTag("live_now_card"),
        colors = CardDefaults.cardColors(containerColor = DarkZincSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Live Pulse
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(LiveRed)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.White)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("LIVE MATCH NOW", fontSize = 10.sp, fontWeight = FontWeight.Black, color = Color.White)
                }

                // Timer Box (00:15:30)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(PitchBlack)
                        .border(1.dp, LiveRed.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Default.Timer, contentDescription = null, tint = LiveRed, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("00:15:30", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LiveRed)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(tournament.title, fontSize = 20.sp, fontWeight = FontWeight.Black, color = TextPrimary)
            Text("${tournament.format} Match | Map: ${tournament.mapName}", fontSize = 12.sp, color = TextMuted)

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(PitchBlack)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Prize Pool: ₹${tournament.prizePool.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PrizeGold)
                Text("Slots: ${tournament.filledSlots}/${tournament.maxSlots} (FULL)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = LiveRed)
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onJoinClick,
                modifier = Modifier.fillMaxWidth().height(42.dp),
                colors = ButtonDefaults.buttonColors(containerColor = LiveRed, contentColor = Color.White),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(if (isJoined) "VIEW MATCH & ROOM ID" else "JOIN LIVE MATCH", fontWeight = FontWeight.Black)
            }
        }
    }
}
