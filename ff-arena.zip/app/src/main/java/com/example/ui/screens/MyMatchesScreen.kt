package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.JoinedMatchEntity
import com.example.ui.MainViewModel
import com.example.ui.theme.DarkZincBorder
import com.example.ui.theme.DarkZincSurface
import com.example.ui.theme.LiveRed
import com.example.ui.theme.NeonLime
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.PrizeGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MyMatchesScreen(viewModel: MainViewModel) {
    val joinedMatches by viewModel.joinedMatches.collectAsState()
    val activeTab by viewModel.myMatchesTab.collectAsState()

    val context = LocalContext.current

    val filteredList = joinedMatches.filter { match ->
        if (activeTab == "Joined") match.status == "JOINED"
        else match.status == "COMPLETED"
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PitchBlack)
            .padding(horizontal = 16.dp)
            .testTag("my_matches_screen_container"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        item {
            Text(
                text = "MY MATCHES",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = TextPrimary
            )
            Text(
                text = "Track registered tournaments and view Room ID & Password",
                fontSize = 12.sp,
                color = TextMuted
            )
        }

        // Sub-tabs: Joined vs Completed
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(DarkZincSurface)
                    .padding(4.dp)
            ) {
                listOf("Joined", "Completed").forEach { tab ->
                    val isSelected = activeTab == tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) NeonLime else PitchBlack)
                            .clickable { viewModel.setMyMatchesTab(tab) }
                            .padding(vertical = 10.dp)
                            .testTag("my_matches_tab_$tab"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (tab == "Joined") "JOINED MATCHES" else "COMPLETED MATCHES",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) PitchBlack else TextPrimary
                        )
                    }
                }
            }
        }

        if (filteredList.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 50.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.SportsEsports, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (activeTab == "Joined") "No registered matches found.\nExplore tournaments to join!" else "No completed matches history.",
                            color = TextMuted,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        } else {
            items(filteredList) { match ->
                JoinedMatchCard(
                    match = match,
                    context = context
                )
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun JoinedMatchCard(
    match: JoinedMatchEntity,
    context: Context
) {
    var isRoomRevealed by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, DarkZincBorder, RoundedCornerShape(14.dp))
            .testTag("match_card_${match.id}"),
        colors = CardDefaults.cardColors(containerColor = DarkZincSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(NeonLime.copy(alpha = 0.15f))
                        .border(1.dp, NeonLime.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(match.format.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NeonLime)
                }

                Text(match.dateTimeString, fontSize = 11.sp, color = TextMuted)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(match.title, fontSize = 18.sp, fontWeight = FontWeight.Black, color = TextPrimary)

            Spacer(modifier = Modifier.height(8.dp))

            // Player Registration Details
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(PitchBlack)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = TextMuted, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("IGN: ${match.ign}", fontSize = 12.sp, color = TextSecondary)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.SportsEsports, contentDescription = null, tint = TextMuted, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("UID: ${match.ffUid}", fontSize = 12.sp, color = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (match.status == "JOINED") {
                // Room Details Section with Reveal Toggle & Copy!
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(PitchBlack)
                        .border(1.dp, if (isRoomRevealed) NeonLime else DarkZincBorder, RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isRoomRevealed) Icons.Default.MeetingRoom else Icons.Default.Lock,
                                contentDescription = null,
                                tint = if (isRoomRevealed) NeonLime else PrizeGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ROOM ID & PASSWORD",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = TextPrimary
                            )
                        }

                        Button(
                            onClick = { isRoomRevealed = !isRoomRevealed },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isRoomRevealed) DarkZincSurface else NeonLime,
                                contentColor = if (isRoomRevealed) TextPrimary else PitchBlack
                            ),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.height(32.dp).testTag("toggle_room_reveal_btn")
                        ) {
                            Icon(
                                imageVector = if (isRoomRevealed) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isRoomRevealed) "HIDE" else "SHOW DETAILS", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (isRoomRevealed) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("ROOM ID", fontSize = 10.sp, color = TextMuted)
                                Text(match.roomId, fontSize = 16.sp, fontWeight = FontWeight.Black, color = NeonLime)
                            }
                            Button(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = ClipData.newPlainText("Room ID", match.roomId)
                                    clipboard.setPrimaryClip(clip)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DarkZincSurface, contentColor = NeonLime),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(32.dp).testTag("copy_room_id_btn")
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Copy ID", fontSize = 11.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("PASSWORD", fontSize = 10.sp, color = TextMuted)
                                Text(match.roomPassword, fontSize = 16.sp, fontWeight = FontWeight.Black, color = PrizeGold)
                            }
                            Button(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = ClipData.newPlainText("Room Password", match.roomPassword)
                                    clipboard.setPrimaryClip(clip)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DarkZincSurface, contentColor = PrizeGold),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(32.dp).testTag("copy_room_pass_btn")
                            ) {
                                Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Copy Pass", fontSize = 11.sp)
                            }
                        }
                    } else {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tap 'SHOW DETAILS' to reveal Room ID & Pass for match entry.",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }
            } else {
                // Completed Match Details
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(PitchBlack)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("POSITION", fontSize = 10.sp, color = TextMuted)
                        Text(match.userPosition, fontSize = 14.sp, fontWeight = FontWeight.Black, color = PrizeGold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("KILLS", fontSize = 10.sp, color = TextMuted)
                        Text("${match.userKills} Kills", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("WON", fontSize = 10.sp, color = TextMuted)
                        Text("₹${match.winningsEarned.toInt()}", fontSize = 14.sp, fontWeight = FontWeight.Black, color = NeonLime)
                    }
                }
            }
        }
    }
}
