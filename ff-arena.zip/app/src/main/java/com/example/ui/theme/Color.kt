package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PitchBlack = Color(0xFF000000)
val DarkZincBg = Color(0xFF09090B)
val DarkZincSurface = Color(0xFF18181B)
val DarkZincSurfaceVariant = Color(0xFF27272A)
val DarkZincBorder = Color(0xFF3F3F46)

val NeonLime = Color(0xFFA3E635)
val NeonLimeDark = Color(0xFF65A30D)
val PrizeGold = Color(0xFFF59E0B)
val LiveRed = Color(0xFFEF4444)
val DiamondBlue = Color(0xFF38BDF8)

val TextPrimary = Color(0xFFFAFAFA)
val TextSecondary = Color(0xFFA1A1AA)
val TextMuted = Color(0xFF71717A)

