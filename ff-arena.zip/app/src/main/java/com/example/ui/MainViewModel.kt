package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.AppRepository
import com.example.data.local.DepositRequestEntity
import com.example.data.local.JoinedMatchEntity
import com.example.data.local.NotificationEntity
import com.example.data.local.PaymentSettingsEntity
import com.example.data.local.TournamentEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.UserProfileEntity
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppTab {
    HOME, TOURNAMENTS, MY_MATCHES, WALLET, PROFILE
}

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppRepository
    private val prefs = application.getSharedPreferences("ff_arena_prefs", Context.MODE_PRIVATE)

    private val _loggedInPhoneNumber = MutableStateFlow(prefs.getString("logged_in_phone", "") ?: "")
    val loggedInPhoneNumber: StateFlow<String> = _loggedInPhoneNumber.asStateFlow()

    val isUserLoggedIn: StateFlow<Boolean> = _loggedInPhoneNumber.map { it.isNotBlank() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), _loggedInPhoneNumber.value.isNotBlank())

    val userProfile: StateFlow<UserProfileEntity?> = _loggedInPhoneNumber.flatMapLatest { phone ->
        if (phone.isNotBlank()) repository.getUserProfile(phone) else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val tournaments: StateFlow<List<TournamentEntity>>
    
    val joinedMatches: StateFlow<List<JoinedMatchEntity>> = _loggedInPhoneNumber.flatMapLatest { phone ->
        if (phone.isNotBlank()) repository.getJoinedMatches(phone) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<TransactionEntity>> = _loggedInPhoneNumber.flatMapLatest { phone ->
        if (phone.isNotBlank()) repository.getTransactions(phone) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = _loggedInPhoneNumber.flatMapLatest { phone ->
        if (phone.isNotBlank()) repository.getNotifications(phone) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val depositRequests: StateFlow<List<DepositRequestEntity>>
    val allUsers: StateFlow<List<UserProfileEntity>>
    val paymentSettings: StateFlow<PaymentSettingsEntity?>

    private val _currentTab = MutableStateFlow(AppTab.HOME)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // Tournament Filter (All, Solo, Duo, Squad)
    private val _tournamentFormatFilter = MutableStateFlow("All")
    val tournamentFormatFilter: StateFlow<String> = _tournamentFormatFilter.asStateFlow()

    private val _tournamentSearchQuery = MutableStateFlow("")
    val tournamentSearchQuery: StateFlow<String> = _tournamentSearchQuery.asStateFlow()

    // My Matches Filter (Joined, Completed)
    private val _myMatchesTab = MutableStateFlow("Joined")
    val myMatchesTab: StateFlow<String> = _myMatchesTab.asStateFlow()

    // Selected Tournament for Join Modal
    private val _selectedTournamentToJoin = MutableStateFlow<TournamentEntity?>(null)
    val selectedTournamentToJoin: StateFlow<TournamentEntity?> = _selectedTournamentToJoin.asStateFlow()

    private val _showInsufficientBalanceModal = MutableStateFlow(false)
    val showInsufficientBalanceModal: StateFlow<Boolean> = _showInsufficientBalanceModal.asStateFlow()

    // Modals Visibility State
    private val _showNotificationsSheet = MutableStateFlow(false)
    val showNotificationsSheet: StateFlow<Boolean> = _showNotificationsSheet.asStateFlow()

    private val _showAddMoneyModal = MutableStateFlow(false)
    val showAddMoneyModal: StateFlow<Boolean> = _showAddMoneyModal.asStateFlow()

    private val _showWithdrawModal = MutableStateFlow(false)
    val showWithdrawModal: StateFlow<Boolean> = _showWithdrawModal.asStateFlow()

    private val _showEditProfileModal = MutableStateFlow(false)
    val showEditProfileModal: StateFlow<Boolean> = _showEditProfileModal.asStateFlow()

    private val _showBuyDiamondsModal = MutableStateFlow(false)
    val showBuyDiamondsModal: StateFlow<Boolean> = _showBuyDiamondsModal.asStateFlow()

    // Admin Panel States
    private val _showAdminLoginModal = MutableStateFlow(false)
    val showAdminLoginModal: StateFlow<Boolean> = _showAdminLoginModal.asStateFlow()

    private val _showAdminPanelModal = MutableStateFlow(false)
    val showAdminPanelModal: StateFlow<Boolean> = _showAdminPanelModal.asStateFlow()

    private val _isAdminLoggedIn = MutableStateFlow(false)
    val isAdminLoggedIn: StateFlow<Boolean> = _isAdminLoggedIn.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        repository = AppRepository(database.appDao())

        tournaments = repository.tournaments.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        depositRequests = repository.depositRequests.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        allUsers = repository.allUsers.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        paymentSettings = repository.paymentSettings.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            null
        )

        viewModelScope.launch {
            repository.seedInitialDataIfNeeded()
        }
    }

    fun loginOrRegister(phoneNumber: String, fullName: String, ffUid: String) {
        val cleanedPhone = phoneNumber.trim().replace(" ", "").replace("-", "")
        if (cleanedPhone.length < 10) {
            showToast("Please enter a valid 10-digit Phone Number.")
            return
        }
        if (fullName.isBlank()) {
            showToast("Please enter your Full Name / IGN.")
            return
        }
        if (ffUid.isBlank() || ffUid.length < 5) {
            showToast("Please enter a valid Free Fire UID.")
            return
        }

        viewModelScope.launch {
            val user = repository.loginOrRegisterUser(cleanedPhone, fullName.trim(), ffUid.trim())
            prefs.edit().putString("logged_in_phone", cleanedPhone).apply()
            _loggedInPhoneNumber.value = cleanedPhone
            showToast("Welcome to FF ARENA, ${user.ign}!")
        }
    }

    fun logout() {
        prefs.edit().remove("logged_in_phone").apply()
        _loggedInPhoneNumber.value = ""
        showToast("Logged out successfully.")
    }

    fun switchTab(tab: AppTab) {
        _currentTab.value = tab
    }

    fun setTournamentFormatFilter(filter: String) {
        _tournamentFormatFilter.value = filter
    }

    fun setTournamentSearchQuery(query: String) {
        _tournamentSearchQuery.value = query
    }

    fun setMyMatchesTab(tab: String) {
        _myMatchesTab.value = tab
    }

    fun openJoinModal(tournament: TournamentEntity) {
        _selectedTournamentToJoin.value = tournament
    }

    fun closeJoinModal() {
        _selectedTournamentToJoin.value = null
    }

    fun setShowNotificationsSheet(show: Boolean) {
        _showNotificationsSheet.value = show
        if (show) {
            viewModelScope.launch {
                val phone = _loggedInPhoneNumber.value
                if (phone.isNotBlank()) {
                    repository.markNotificationsRead(phone)
                }
            }
        }
    }

    fun setShowAddMoneyModal(show: Boolean) {
        _showAddMoneyModal.value = show
    }

    fun setShowWithdrawModal(show: Boolean) {
        _showWithdrawModal.value = show
    }

    fun setShowEditProfileModal(show: Boolean) {
        _showEditProfileModal.value = show
    }

    fun setShowBuyDiamondsModal(show: Boolean) {
        _showBuyDiamondsModal.value = show
    }

    // --- ADMIN ACTIONS ---

    fun setShowAdminLoginModal(show: Boolean) {
        _showAdminLoginModal.value = show
    }

    fun setShowAdminPanelModal(show: Boolean) {
        _showAdminPanelModal.value = show
    }

    fun verifyAdminPin(pin: String): Boolean {
        if (pin.trim() == "0066") {
            _isAdminLoggedIn.value = true
            _showAdminLoginModal.value = false
            _showAdminPanelModal.value = true
            showToast("Admin access granted!")
            return true
        } else {
            showToast("Invalid PIN! Access denied.")
            return false
        }
    }

    fun submitDepositRequest(amount: Double, utrNumber: String) {
        val phone = _loggedInPhoneNumber.value
        if (phone.isBlank()) {
            showToast("Please log in first.")
            return
        }
        if (amount <= 0) {
            showToast("Please enter a valid amount.")
            return
        }
        if (utrNumber.isBlank() || utrNumber.length < 6) {
            showToast("Please enter a valid Transaction / UTR ID.")
            return
        }

        viewModelScope.launch {
            repository.submitDepositRequest(phone, amount, utrNumber.trim())
            _showAddMoneyModal.value = false
            showToast("Deposit request submitted! Admin will verify UTR and credit wallet.")
        }
    }

    fun approveDeposit(request: DepositRequestEntity) {
        viewModelScope.launch {
            repository.approveDepositRequest(request)
            showToast("Approved deposit of ₹${request.amount} for ${request.userName}!")
        }
    }

    fun rejectDeposit(request: DepositRequestEntity) {
        viewModelScope.launch {
            repository.rejectDepositRequest(request)
            showToast("Rejected deposit of ₹${request.amount} for ${request.userName}.")
        }
    }

    fun setShowInsufficientBalanceModal(show: Boolean) {
        _showInsufficientBalanceModal.value = show
    }

    fun updatePaymentSettings(qrImageUrl: String, upiOrNumber: String, instructions: String) {
        viewModelScope.launch {
            repository.updatePaymentSettings(qrImageUrl, upiOrNumber, instructions)
            showToast("Payment Settings updated successfully!")
        }
    }

    fun declareWinner(tournamentId: String, winnerPhoneNumber: String, prizeAmount: Double) {
        if (winnerPhoneNumber.isBlank()) {
            showToast("Please select a winning player.")
            return
        }
        if (prizeAmount <= 0) {
            showToast("Please enter a valid Prize Amount.")
            return
        }
        viewModelScope.launch {
            val res = repository.declareTournamentWinner(tournamentId, winnerPhoneNumber, prizeAmount)
            res.onSuccess {
                showToast("Winner declared! Prize credited to player's wallet.")
            }.onFailure { err ->
                showToast(err.message ?: "Failed to declare winner.")
            }
        }
    }

    fun createTournament(
        title: String,
        format: String,
        entryFeeDiamonds: Int,
        entryFeeRupees: Double = 10.0,
        prizePool: Double,
        maxSlots: Int,
        mapName: String,
        dateTimeString: String,
        roomId: String,
        roomPassword: String
    ) {
        if (title.isBlank() || mapName.isBlank()) {
            showToast("Please fill all required fields.")
            return
        }

        val newTournament = TournamentEntity(
            id = "t_admin_${System.currentTimeMillis()}",
            title = title.trim(),
            format = format,
            entryFeeDiamonds = entryFeeDiamonds,
            entryFeeRupees = entryFeeRupees,
            prizePool = prizePool,
            filledSlots = 0,
            maxSlots = maxSlots,
            status = "UPCOMING",
            dateTimeString = dateTimeString.ifBlank { "Upcoming Today" },
            mapName = mapName.ifBlank { "Bermuda" },
            roomId = roomId.ifBlank { "TBD" },
            roomPassword = roomPassword.ifBlank { "TBD" }
        )

        viewModelScope.launch {
            repository.createTournament(newTournament)
            showToast("New Tournament '${title}' created successfully!")
        }
    }

    fun updateRoomCredentials(tournamentId: String, roomId: String, roomPassword: String) {
        if (roomId.isBlank() || roomPassword.isBlank()) {
            showToast("Room ID and Password cannot be empty.")
            return
        }

        viewModelScope.launch {
            repository.updateRoomCredentials(tournamentId, roomId.trim(), roomPassword.trim())
            showToast("Room ID & Password updated and released!")
        }
    }

    fun joinTournament(ign: String, ffUid: String) {
        val phone = _loggedInPhoneNumber.value
        if (phone.isBlank()) {
            showToast("Please register or log in first!")
            return
        }
        val tournament = _selectedTournamentToJoin.value ?: return
        if (ign.isBlank() || ffUid.isBlank()) {
            showToast("Please enter both In-Game Name and Free Fire UID.")
            return
        }

        viewModelScope.launch {
            val result = repository.joinTournament(phone, tournament, ign.trim(), ffUid.trim())
            result.onSuccess {
                _selectedTournamentToJoin.value = null
                showToast("Successfully Joined ${tournament.title}! Added to My Matches.")
            }.onFailure { err ->
                if (err.message == "INSUFFICIENT_BALANCE") {
                    _showInsufficientBalanceModal.value = true
                } else {
                    showToast(err.message ?: "Failed to join tournament.")
                }
            }
        }
    }

    fun updateProfile(ign: String, ffUid: String) {
        val phone = _loggedInPhoneNumber.value
        if (phone.isBlank()) return
        if (ign.isBlank() || ffUid.isBlank()) {
            showToast("IGN and FF UID cannot be empty.")
            return
        }
        viewModelScope.launch {
            repository.updateProfile(phone, ign.trim(), ffUid.trim())
            _showEditProfileModal.value = false
            showToast("Profile updated successfully!")
        }
    }

    fun withdrawMoney(amount: Double, upiId: String) {
        val phone = _loggedInPhoneNumber.value
        if (phone.isBlank()) return
        if (amount <= 0 || upiId.isBlank()) {
            showToast("Enter valid amount and UPI ID.")
            return
        }
        viewModelScope.launch {
            val success = repository.withdrawMoney(phone, amount, upiId.trim())
            if (success) {
                _showWithdrawModal.value = false
                showToast("Withdrawal request of ₹${String.format("%.2f", amount)} submitted!")
            } else {
                showToast("Insufficient Balance for Withdrawal!")
            }
        }
    }

    fun convertRupeesToDiamonds(rupeesAmount: Double, diamondsAmount: Int) {
        val phone = _loggedInPhoneNumber.value
        if (phone.isBlank()) return
        viewModelScope.launch {
            val success = repository.convertRupeesToDiamonds(phone, rupeesAmount, diamondsAmount)
            if (success) {
                _showBuyDiamondsModal.value = false
                showToast("Successfully purchased $diamondsAmount Diamonds!")
            } else {
                showToast("Insufficient Balance! Please Add Money first.")
            }
        }
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    private fun showToast(msg: String) {
        _toastMessage.value = msg
    }
}
