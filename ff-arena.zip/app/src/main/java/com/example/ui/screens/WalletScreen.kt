package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.theme.DarkZincBorder
import com.example.ui.theme.DarkZincSurface
import com.example.ui.theme.DiamondBlue
import com.example.ui.theme.LiveRed
import com.example.ui.theme.NeonLime
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.PrizeGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun WalletScreen(viewModel: MainViewModel) {
    val profile by viewModel.userProfile.collectAsState()
    val transactions by viewModel.transactions.collectAsState()

    val rupees = profile?.rupeesBalance ?: 0.0
    val diamonds = profile?.diamondsBalance ?: 0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PitchBlack)
            .padding(horizontal = 16.dp)
            .testTag("wallet_screen_container"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        item {
            Text(
                text = "MY WALLET",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = TextPrimary
            )
            Text(
                text = "Manage cash balance, diamonds & transaction history",
                fontSize = 12.sp,
                color = TextMuted
            )
        }

        // WALLET BALANCE CARDS
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, DarkZincBorder, RoundedCornerShape(16.dp))
                    .testTag("wallet_balance_card"),
                colors = CardDefaults.cardColors(containerColor = DarkZincSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(DarkZincSurface, PitchBlack)
                            )
                        )
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("RUPEES BALANCE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                            Text(
                                text = "₹${String.format("%.2f", rupees)}",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Black,
                                color = PrizeGold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .height(40.dp)
                                .width(1.dp)
                                .background(DarkZincBorder)
                        )

                        Column(horizontalAlignment = Alignment.End) {
                            Text("DIAMONDS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Diamond, contentDescription = null, tint = DiamondBlue, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "$diamonds",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black,
                                    color = DiamondBlue
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // ACTION BUTTONS: Add Money, Withdraw, Buy Diamonds
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.setShowAddMoneyModal(true) },
                            modifier = Modifier.weight(1f).height(44.dp).testTag("btn_add_money"),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonLime, contentColor = PitchBlack),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ADD MONEY", fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }

                        Button(
                            onClick = { viewModel.setShowWithdrawModal(true) },
                            modifier = Modifier.weight(1f).height(44.dp).testTag("btn_withdraw"),
                            colors = ButtonDefaults.buttonColors(containerColor = PrizeGold, contentColor = PitchBlack),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("WITHDRAW", fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }

                        Button(
                            onClick = { viewModel.setShowBuyDiamondsModal(true) },
                            modifier = Modifier.weight(1f).height(44.dp).testTag("btn_buy_diamonds"),
                            colors = ButtonDefaults.buttonColors(containerColor = DiamondBlue, contentColor = PitchBlack),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("BUY 💎", fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }

        // RECENT TRANSACTIONS
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Icon(Icons.Default.History, contentDescription = null, tint = NeonLime)
                Spacer(modifier = Modifier.width(8.dp))
                Text("TRANSACTION HISTORY", fontSize = 15.sp, fontWeight = FontWeight.Black, color = TextPrimary)
            }
        }

        if (transactions.isEmpty()) {
            item {
                Text("No transactions yet.", color = TextMuted, fontSize = 13.sp)
            }
        } else {
            items(transactions) { tx ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkZincSurface)
                        .border(1.dp, DarkZincBorder, RoundedCornerShape(10.dp))
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(tx.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text(tx.timestamp, fontSize = 10.sp, color = TextMuted)
                    }

                    Text(
                        text = tx.amountString,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        color = if (tx.isCredit) NeonLime else LiveRed
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
