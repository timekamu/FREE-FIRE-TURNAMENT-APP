package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.TournamentEntity
import com.example.data.local.UserProfileEntity
import com.example.ui.theme.DarkZincBorder
import com.example.ui.theme.DarkZincSurface
import com.example.ui.theme.DarkZincSurfaceVariant
import com.example.ui.theme.DiamondBlue
import com.example.ui.theme.LiveRed
import com.example.ui.theme.NeonLime
import com.example.ui.theme.PitchBlack
import com.example.ui.theme.PrizeGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun JoinTournamentModal(
    tournament: TournamentEntity,
    userProfile: UserProfileEntity?,
    onDismiss: () -> Unit,
    onConfirmJoin: (ign: String, ffUid: String) -> Unit
) {
    var ignInput by remember(userProfile) { mutableStateOf(userProfile?.ign ?: "") }
    var ffUidInput by remember(userProfile) { mutableStateOf(userProfile?.ffUid ?: "") }

    val userDiamonds = userProfile?.diamondsBalance ?: 0
    val hasEnoughDiamonds = userDiamonds >= tournament.entryFeeDiamonds

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, NeonLime.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .testTag("join_tournament_modal"),
            colors = CardDefaults.cardColors(containerColor = DarkZincSurface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header with Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "JOIN TOURNAMENT",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            color = NeonLime,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = tournament.title,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("modal_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Summary Box (Format, Prize, Fee)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(PitchBlack)
                        .border(1.dp, DarkZincBorder, RoundedCornerShape(10.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("FORMAT", fontSize = 10.sp, color = TextMuted)
                        Text(tournament.format, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Box(modifier = Modifier.height(20.dp).width(1.dp).background(DarkZincBorder))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("PRIZE POOL", fontSize = 10.sp, color = TextMuted)
                        Text("₹${tournament.prizePool.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PrizeGold)
                    }
                    Box(modifier = Modifier.height(20.dp).width(1.dp).background(DarkZincBorder))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("ENTRY FEE", fontSize = 10.sp, color = TextMuted)
                        Text("${tournament.entryFeeDiamonds} 💎", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DiamondBlue)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Input Fields
                Text(
                    text = "Player Registration Details",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = ignInput,
                    onValueChange = { ignInput = it },
                    label = { Text("In-Game Name (IGN)") },
                    leadingIcon = {
                        Icon(Icons.Default.Person, contentDescription = null, tint = NeonLime)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_ign"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonLime,
                        unfocusedBorderColor = DarkZincBorder,
                        focusedLabelColor = NeonLime,
                        unfocusedLabelColor = TextMuted,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = PitchBlack,
                        unfocusedContainerColor = PitchBlack
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = ffUidInput,
                    onValueChange = { ffUidInput = it },
                    label = { Text("Free Fire UID") },
                    leadingIcon = {
                        Icon(Icons.Default.SportsEsports, contentDescription = null, tint = NeonLime)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_ff_uid"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonLime,
                        unfocusedBorderColor = DarkZincBorder,
                        focusedLabelColor = NeonLime,
                        unfocusedLabelColor = TextMuted,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = PitchBlack,
                        unfocusedContainerColor = PitchBlack
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Wallet Diamonds Status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Your Balance: $userDiamonds Diamonds",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (hasEnoughDiamonds) NeonLime else LiveRed
                    )

                    Text(
                        text = "Deduction: -${tournament.entryFeeDiamonds} 💎",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }

                if (!hasEnoughDiamonds) {
                    Text(
                        text = "⚠️ Insufficient Diamonds! Go to Wallet tab or buy diamonds.",
                        fontSize = 11.sp,
                        color = LiveRed,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Submit Button
                Button(
                    onClick = { onConfirmJoin(ignInput, ffUidInput) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("confirm_join_submit_button"),
                    enabled = hasEnoughDiamonds && ignInput.isNotBlank() && ffUidInput.isNotBlank(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonLime,
                        contentColor = PitchBlack,
                        disabledContainerColor = DarkZincSurfaceVariant,
                        disabledContentColor = TextMuted
                    )
                ) {
                    Text(
                        text = "CONFIRM & PAY ${tournament.entryFeeDiamonds} DIAMONDS",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}
