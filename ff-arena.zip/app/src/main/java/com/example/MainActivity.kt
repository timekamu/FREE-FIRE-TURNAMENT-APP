package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.example.ui.AppTab
import com.example.ui.MainViewModel
import com.example.ui.components.AddMoneyModal
import com.example.ui.components.AdminLoginModal
import com.example.ui.components.AdminPanelModal
import com.example.ui.components.BottomNavBar
import com.example.ui.components.BuyDiamondsModal
import com.example.ui.components.EditProfileModal
import com.example.ui.components.HeaderTopBar
import com.example.ui.components.JoinTournamentModal
import com.example.ui.components.NotificationsSheet
import com.example.ui.components.WithdrawModal
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MyMatchesScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.TournamentsScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.theme.FFArenaTheme
import com.example.ui.theme.PitchBlack

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            FFArenaTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: MainViewModel) {
    val isUserLoggedIn by viewModel.isUserLoggedIn.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    val selectedTournamentToJoin by viewModel.selectedTournamentToJoin.collectAsState()
    val showNotificationsSheet by viewModel.showNotificationsSheet.collectAsState()
    val showAddMoneyModal by viewModel.showAddMoneyModal.collectAsState()
    val showWithdrawModal by viewModel.showWithdrawModal.collectAsState()
    val showEditProfileModal by viewModel.showEditProfileModal.collectAsState()
    val showBuyDiamondsModal by viewModel.showBuyDiamondsModal.collectAsState()

    val showAdminLoginModal by viewModel.showAdminLoginModal.collectAsState()
    val showAdminPanelModal by viewModel.showAdminPanelModal.collectAsState()
    val showInsufficientBalanceModal by viewModel.showInsufficientBalanceModal.collectAsState()
    val tournaments by viewModel.tournaments.collectAsState()
    val depositRequests by viewModel.depositRequests.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState()
    val paymentSettings by viewModel.paymentSettings.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(toastMessage) {
        toastMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    if (!isUserLoggedIn) {
        Box(modifier = Modifier.fillMaxSize()) {
            AuthScreen(viewModel = viewModel)
            
            if (showAdminLoginModal) {
                AdminLoginModal(
                    onDismiss = { viewModel.setShowAdminLoginModal(false) },
                    onVerifyPin = { pin -> viewModel.verifyAdminPin(pin) }
                )
            }

            if (showAdminPanelModal) {
                AdminPanelModal(
                    tournaments = tournaments,
                    depositRequests = depositRequests,
                    allUsers = allUsers,
                    paymentSettings = paymentSettings,
                    onDismiss = { viewModel.setShowAdminPanelModal(false) },
                    onCreateTournament = { title, format, entryFeeDiamonds, prizePool, maxSlots, mapName, dateTimeString, roomId, roomPassword ->
                        viewModel.createTournament(title, format, entryFeeDiamonds, 10.0, prizePool, maxSlots, mapName, dateTimeString, roomId, roomPassword)
                    },
                    onUpdateRoomCredentials = { tournamentId, roomId, roomPassword ->
                        viewModel.updateRoomCredentials(tournamentId, roomId, roomPassword)
                    },
                    onApproveDeposit = { request -> viewModel.approveDeposit(request) },
                    onRejectDeposit = { request -> viewModel.rejectDeposit(request) },
                    onSavePaymentSettings = { qrUrl, upi, instr -> viewModel.updatePaymentSettings(qrUrl, upi, instr) },
                    onDeclareWinner = { tId, phone, prize -> viewModel.declareWinner(tId, phone, prize) }
                )
            }
        }
        return
    }

    val unreadNotifCount = notifications.count { !it.isRead }
    val userIgn = userProfile?.ign ?: "SK"

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars)
            .background(PitchBlack),
        topBar = {
            HeaderTopBar(
                unreadNotificationCount = unreadNotifCount,
                userIgn = userIgn,
                onNotificationClick = { viewModel.setShowNotificationsSheet(true) },
                onAvatarClick = { viewModel.switchTab(AppTab.PROFILE) },
                onAdminClick = { viewModel.setShowAdminLoginModal(true) }
            )
        },
        bottomBar = {
            BottomNavBar(
                currentTab = currentTab,
                onTabSelected = { viewModel.switchTab(it) }
            )
        },
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState)
        },
        containerColor = PitchBlack
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(PitchBlack)
        ) {
            when (currentTab) {
                AppTab.HOME -> HomeScreen(
                    viewModel = viewModel,
                    onNavigateToTournaments = { viewModel.switchTab(AppTab.TOURNAMENTS) }
                )
                AppTab.TOURNAMENTS -> TournamentsScreen(
                    viewModel = viewModel
                )
                AppTab.MY_MATCHES -> MyMatchesScreen(
                    viewModel = viewModel
                )
                AppTab.WALLET -> WalletScreen(
                    viewModel = viewModel
                )
                AppTab.PROFILE -> ProfileScreen(
                    viewModel = viewModel
                )
            }
        }
    }

    // Interactive Modals
    selectedTournamentToJoin?.let { tournament ->
        JoinTournamentModal(
            tournament = tournament,
            userProfile = userProfile,
            onDismiss = { viewModel.closeJoinModal() },
            onConfirmJoin = { ign, ffUid ->
                viewModel.joinTournament(ign, ffUid)
            }
        )
    }

    if (showNotificationsSheet) {
        NotificationsSheet(
            notifications = notifications,
            onDismiss = { viewModel.setShowNotificationsSheet(false) }
        )
    }

    if (showAddMoneyModal) {
        AddMoneyModal(
            paymentSettings = paymentSettings,
            onDismiss = { viewModel.setShowAddMoneyModal(false) },
            onConfirmAddMoney = { amount, utrNumber -> viewModel.submitDepositRequest(amount, utrNumber) }
        )
    }

    if (showInsufficientBalanceModal) {
        com.example.ui.components.InsufficientBalanceModal(
            onDismiss = { viewModel.setShowInsufficientBalanceModal(false) },
            onOpenWallet = { viewModel.setShowAddMoneyModal(true) }
        )
    }

    if (showWithdrawModal) {
        WithdrawModal(
            currentBalance = userProfile?.rupeesBalance ?: 0.0,
            onDismiss = { viewModel.setShowWithdrawModal(false) },
            onConfirmWithdraw = { amount, upiId -> viewModel.withdrawMoney(amount, upiId) }
        )
    }

    if (showEditProfileModal) {
        EditProfileModal(
            userProfile = userProfile,
            onDismiss = { viewModel.setShowEditProfileModal(false) },
            onSaveProfile = { ign, ffUid -> viewModel.updateProfile(ign, ffUid) }
        )
    }

    if (showBuyDiamondsModal) {
        BuyDiamondsModal(
            onDismiss = { viewModel.setShowBuyDiamondsModal(false) },
            onBuy = { rupees, diamonds -> viewModel.convertRupeesToDiamonds(rupees, diamonds) }
        )
    }

    if (showAdminLoginModal) {
        AdminLoginModal(
            onDismiss = { viewModel.setShowAdminLoginModal(false) },
            onVerifyPin = { pin -> viewModel.verifyAdminPin(pin) }
        )
    }

    if (showAdminPanelModal) {
        AdminPanelModal(
            tournaments = tournaments,
            depositRequests = depositRequests,
            allUsers = allUsers,
            paymentSettings = paymentSettings,
            onDismiss = { viewModel.setShowAdminPanelModal(false) },
            onCreateTournament = { title, format, entryFeeDiamonds, prizePool, maxSlots, mapName, dateTimeString, roomId, roomPassword ->
                viewModel.createTournament(title, format, entryFeeDiamonds, 10.0, prizePool, maxSlots, mapName, dateTimeString, roomId, roomPassword)
            },
            onUpdateRoomCredentials = { tournamentId, roomId, roomPassword ->
                viewModel.updateRoomCredentials(tournamentId, roomId, roomPassword)
            },
            onApproveDeposit = { request -> viewModel.approveDeposit(request) },
            onRejectDeposit = { request -> viewModel.rejectDeposit(request) },
            onSavePaymentSettings = { qrUrl, upi, instr -> viewModel.updatePaymentSettings(qrUrl, upi, instr) },
            onDeclareWinner = { tId, phone, prize -> viewModel.declareWinner(tId, phone, prize) }
        )
    }
}
