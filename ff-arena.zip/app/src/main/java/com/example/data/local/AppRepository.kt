package com.example.data.local

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class AppRepository(private val dao: AppDao) {

    fun getUserProfile(phoneNumber: String): Flow<UserProfileEntity?> = dao.getUserProfileByPhone(phoneNumber)
    val tournaments: Flow<List<TournamentEntity>> = dao.getAllTournaments()
    fun getJoinedMatches(phoneNumber: String): Flow<List<JoinedMatchEntity>> = dao.getJoinedMatchesForUser(phoneNumber)
    fun getTransactions(phoneNumber: String): Flow<List<TransactionEntity>> = dao.getTransactionsForUser(phoneNumber)
    fun getNotifications(phoneNumber: String): Flow<List<NotificationEntity>> = dao.getNotificationsForUser(phoneNumber)
    val depositRequests: Flow<List<DepositRequestEntity>> = dao.getDepositRequests()
    val allUsers: Flow<List<UserProfileEntity>> = dao.getAllUsers()
    val paymentSettings: Flow<PaymentSettingsEntity?> = dao.getPaymentSettings()

    suspend fun seedInitialDataIfNeeded() {
        val existingSettings = dao.getPaymentSettingsDirect()
        if (existingSettings == null) {
            dao.insertOrUpdatePaymentSettings(
                PaymentSettingsEntity(
                    id = 1,
                    qrImageUrl = "",
                    upiOrNumber = "9876543210@upi",
                    instructions = "Scan QR Code or send payment to the UPI ID / Number above. Submit 12-digit UTR reference number for approval."
                )
            )
        }

        val existingUsers = dao.getAllUsers().firstOrNull()
        if (existingUsers.isNullOrEmpty()) {
            val defaultUser = UserProfileEntity(
                phoneNumber = "9876543210",
                ign = "SK_GAMER_99",
                ffUid = "8274910283",
                rupeesBalance = 250.0,
                diamondsBalance = 120,
                matchesPlayed = 42,
                totalKills = 188,
                totalEarnings = 4850.0
            )
            dao.insertOrUpdateProfile(defaultUser)

            // Seed Tournaments
            val initialTournaments = listOf(
                TournamentEntity(
                    id = "t_live_1",
                    title = "FF ARENA CHAMPIONSHIP",
                    format = "Squad",
                    entryFeeDiamonds = 50,
                    prizePool = 10000.0,
                    filledSlots = 48,
                    maxSlots = 48,
                    status = "LIVE",
                    dateTimeString = "LIVE NOW",
                    mapName = "Bermuda",
                    roomId = "8839210",
                    roomPassword = "FF2026"
                ),
                TournamentEntity(
                    id = "t_upcoming_1",
                    title = "Elite Showdown",
                    format = "Squad",
                    entryFeeDiamonds = 60,
                    prizePool = 15000.0,
                    filledSlots = 42,
                    maxSlots = 48,
                    status = "UPCOMING",
                    dateTimeString = "Today, 8:00 PM",
                    mapName = "Purgatory",
                    roomId = "9182374",
                    roomPassword = "ELITE77"
                ),
                TournamentEntity(
                    id = "t_upcoming_2",
                    title = "Solo Rush",
                    format = "Solo",
                    entryFeeDiamonds = 20,
                    prizePool = 5000.0,
                    filledSlots = 35,
                    maxSlots = 50,
                    status = "UPCOMING",
                    dateTimeString = "Today, 9:30 PM",
                    mapName = "Kalahari",
                    roomId = "7721839",
                    roomPassword = "RUSH01"
                ),
                TournamentEntity(
                    id = "t_upcoming_3",
                    title = "Duo Battle",
                    format = "Duo",
                    entryFeeDiamonds = 30,
                    prizePool = 7500.0,
                    filledSlots = 38,
                    maxSlots = 40,
                    status = "UPCOMING",
                    dateTimeString = "Tomorrow, 6:00 PM",
                    mapName = "Alpine",
                    roomId = "6612948",
                    roomPassword = "DUO123"
                ),
                TournamentEntity(
                    id = "t_upcoming_4",
                    title = "Pro Survival League",
                    format = "Squad",
                    entryFeeDiamonds = 100,
                    prizePool = 25000.0,
                    filledSlots = 40,
                    maxSlots = 48,
                    status = "UPCOMING",
                    dateTimeString = "Tomorrow, 9:00 PM",
                    mapName = "Bermuda Remastered",
                    roomId = "5591823",
                    roomPassword = "PRO999"
                )
            )
            dao.insertTournaments(initialTournaments)

            // Seed Joined Matches
            val initialJoinedMatches = listOf(
                JoinedMatchEntity(
                    userPhoneNumber = "9876543210",
                    tournamentId = "t_live_1",
                    title = "FF ARENA CHAMPIONSHIP",
                    format = "Squad",
                    ign = "SK_GAMER_99",
                    ffUid = "8274910283",
                    entryFeePaid = 50,
                    prizePool = 10000.0,
                    dateTimeString = "LIVE NOW",
                    status = "JOINED",
                    roomId = "8839210",
                    roomPassword = "FF2026"
                ),
                JoinedMatchEntity(
                    userPhoneNumber = "9876543210",
                    tournamentId = "t_completed_1",
                    title = "Clash Squad Warfare",
                    format = "Squad",
                    ign = "SK_GAMER_99",
                    ffUid = "8274910283",
                    entryFeePaid = 40,
                    prizePool = 8000.0,
                    dateTimeString = "Yesterday",
                    status = "COMPLETED",
                    roomId = "7712390",
                    roomPassword = "CSW123",
                    userKills = 8,
                    userPosition = "#1 Winner",
                    winningsEarned = 1200.0
                )
            )
            initialJoinedMatches.forEach { dao.insertJoinedMatch(it) }

            // Seed Transactions
            val initialTransactions = listOf(
                TransactionEntity(
                    userPhoneNumber = "9876543210",
                    type = "WINNING",
                    title = "Winnings (CS Warfare #1)",
                    amountString = "+ ₹1,200.00",
                    isCredit = true,
                    timestamp = "Yesterday"
                ),
                TransactionEntity(
                    userPhoneNumber = "9876543210",
                    type = "MATCH_FEE",
                    title = "Match Fee (FF Championship)",
                    amountString = "- 50 Diamonds",
                    isCredit = false,
                    timestamp = "Today"
                ),
                TransactionEntity(
                    userPhoneNumber = "9876543210",
                    type = "DEPOSIT",
                    title = "UPI Deposit",
                    amountString = "+ ₹500.00",
                    isCredit = true,
                    timestamp = "2 days ago"
                )
            )
            dao.insertTransactions(initialTransactions)

            // Seed Notifications
            val initialNotifications = listOf(
                NotificationEntity(
                    userPhoneNumber = "9876543210",
                    title = "Room Credentials Released!",
                    message = "Room ID: 8839210 & Pass: FF2026 for FF ARENA CHAMPIONSHIP is now live.",
                    timeAgo = "10m ago"
                ),
                NotificationEntity(
                    userPhoneNumber = "9876543210",
                    title = "Registration Confirmed",
                    message = "You successfully registered for FF ARENA CHAMPIONSHIP.",
                    timeAgo = "1h ago"
                )
            )
            dao.insertNotifications(initialNotifications)
        }
    }

    suspend fun loginOrRegisterUser(phone: String, ign: String, ffUid: String): UserProfileEntity {
        val existing = dao.getUserByPhoneDirect(phone)
        if (existing != null) {
            val updated = if (ign.isNotBlank() && ffUid.isNotBlank()) {
                existing.copy(ign = ign, ffUid = ffUid)
            } else {
                existing
            }
            dao.insertOrUpdateProfile(updated)
            return updated
        } else {
            val newUser = UserProfileEntity(
                phoneNumber = phone,
                ign = if (ign.isNotBlank()) ign else "Player_${phone.takeLast(4)}",
                ffUid = if (ffUid.isNotBlank()) ffUid else "1002003004",
                rupeesBalance = 200.0,
                diamondsBalance = 100,
                matchesPlayed = 0,
                totalKills = 0,
                totalEarnings = 0.0
            )
            dao.insertOrUpdateProfile(newUser)
            return newUser
        }
    }

    suspend fun joinTournament(
        userPhone: String,
        tournament: TournamentEntity,
        ign: String,
        ffUid: String
    ): Result<Unit> {
        val currentProfile = dao.getUserByPhoneDirect(userPhone)
            ?: return Result.failure(Exception("User profile not found!"))

        val feeRupees = tournament.entryFeeRupees
        val feeDiamonds = tournament.entryFeeDiamonds

        // Check wallet balance
        val canPayRupees = currentProfile.rupeesBalance >= feeRupees
        val canPayDiamonds = currentProfile.diamondsBalance >= feeDiamonds

        if (!canPayRupees && !canPayDiamonds) {
            return Result.failure(Exception("INSUFFICIENT_BALANCE"))
        }

        // Deduct fee (prefer Rupees if available, else Diamonds)
        val updatedProfile = if (canPayRupees) {
            currentProfile.copy(
                rupeesBalance = currentProfile.rupeesBalance - feeRupees,
                matchesPlayed = currentProfile.matchesPlayed + 1
            )
        } else {
            currentProfile.copy(
                diamondsBalance = currentProfile.diamondsBalance - feeDiamonds,
                matchesPlayed = currentProfile.matchesPlayed + 1
            )
        }
        dao.insertOrUpdateProfile(updatedProfile)

        // Increment tournament slot
        val updatedTournament = tournament.copy(
            filledSlots = (tournament.filledSlots + 1).coerceAtMost(tournament.maxSlots)
        )
        dao.updateTournament(updatedTournament)

        // Add to Joined Matches
        val joinedMatch = JoinedMatchEntity(
            userPhoneNumber = userPhone,
            tournamentId = tournament.id,
            title = tournament.title,
            format = tournament.format,
            ign = ign,
            ffUid = ffUid,
            entryFeePaid = feeDiamonds,
            prizePool = tournament.prizePool,
            dateTimeString = tournament.dateTimeString,
            status = "JOINED",
            roomId = tournament.roomId,
            roomPassword = tournament.roomPassword
        )
        dao.insertJoinedMatch(joinedMatch)

        // Add Transaction
        val feeText = if (canPayRupees) "- ₹${feeRupees.toInt()}" else "- $feeDiamonds Diamonds"
        val tx = TransactionEntity(
            userPhoneNumber = userPhone,
            type = "MATCH_FEE",
            title = "Match Entry Fee Deducted (${tournament.title})",
            amountString = feeText,
            isCredit = false,
            timestamp = "Just Now"
        )
        dao.insertTransaction(tx)

        // Add Notification
        val notif = NotificationEntity(
            userPhoneNumber = userPhone,
            title = "Joined ${tournament.title}",
            message = "Your slot is confirmed. IGN: $ign | UID: $ffUid",
            timeAgo = "Just Now"
        )
        dao.insertNotifications(listOf(notif))

        return Result.success(Unit)
    }

    suspend fun updatePaymentSettings(qrImageUrl: String, upiOrNumber: String, instructions: String) {
        dao.insertOrUpdatePaymentSettings(
            PaymentSettingsEntity(
                id = 1,
                qrImageUrl = qrImageUrl.trim(),
                upiOrNumber = upiOrNumber.trim(),
                instructions = instructions.trim()
            )
        )
    }

    suspend fun declareTournamentWinner(
        tournamentId: String,
        winnerPhoneNumber: String,
        prizeAmount: Double
    ): Result<Unit> {
        val tournament = dao.getTournamentById(tournamentId)
            ?: return Result.failure(Exception("Tournament not found"))

        val winner = dao.getUserByPhoneDirect(winnerPhoneNumber)
            ?: return Result.failure(Exception("Winning user profile not found"))

        // Credit Prize Amount directly to winner's Wallet Balance
        val updatedWinner = winner.copy(
            rupeesBalance = winner.rupeesBalance + prizeAmount,
            totalEarnings = winner.totalEarnings + prizeAmount,
            matchesPlayed = winner.matchesPlayed + 1
        )
        dao.insertOrUpdateProfile(updatedWinner)

        // Log transaction in user history: "Tournament Winnings Credited (+₹90)"
        val tx = TransactionEntity(
            userPhoneNumber = winnerPhoneNumber,
            type = "WINNING",
            title = "Tournament Winnings Credited (${tournament.title})",
            amountString = "+ ₹${String.format("%.2f", prizeAmount)}",
            isCredit = true,
            timestamp = "Just Now"
        )
        dao.insertTransaction(tx)

        // Send Notification to Winner
        val notif = NotificationEntity(
            userPhoneNumber = winnerPhoneNumber,
            title = "🏆 Winner Declared!",
            message = "Congratulations ${winner.ign}! You won ₹${String.format("%.2f", prizeAmount)} in '${tournament.title}'. Amount credited to your wallet balance.",
            timeAgo = "Just Now"
        )
        dao.insertNotifications(listOf(notif))

        // Mark match status as Completed on Home and My Matches tabs
        val updatedTournament = tournament.copy(status = "COMPLETED")
        dao.updateTournament(updatedTournament)
        dao.updateJoinedMatchesStatus(tournamentId, "COMPLETED")

        return Result.success(Unit)
    }

    suspend fun updateProfile(userPhone: String, ign: String, ffUid: String) {
        val current = dao.getUserByPhoneDirect(userPhone) ?: return
        dao.insertOrUpdateProfile(current.copy(ign = ign, ffUid = ffUid))
    }

    suspend fun convertRupeesToDiamonds(userPhone: String, rupeesAmount: Double, diamondsAmount: Int): Boolean {
        val current = dao.getUserByPhoneDirect(userPhone) ?: return false
        if (current.rupeesBalance < rupeesAmount) return false

        dao.insertOrUpdateProfile(
            current.copy(
                rupeesBalance = current.rupeesBalance - rupeesAmount,
                diamondsBalance = current.diamondsBalance + diamondsAmount
            )
        )

        dao.insertTransaction(
            TransactionEntity(
                userPhoneNumber = userPhone,
                type = "MATCH_FEE",
                title = "Diamond Purchase",
                amountString = "+ $diamondsAmount Diamonds",
                isCredit = true,
                timestamp = "Just Now"
            )
        )
        return true
    }

    suspend fun withdrawMoney(userPhone: String, rupeesAmount: Double, upiId: String): Boolean {
        val current = dao.getUserByPhoneDirect(userPhone) ?: return false
        if (current.rupeesBalance < rupeesAmount) return false

        dao.insertOrUpdateProfile(
            current.copy(rupeesBalance = current.rupeesBalance - rupeesAmount)
        )

        dao.insertTransaction(
            TransactionEntity(
                userPhoneNumber = userPhone,
                type = "WITHDRAWAL",
                title = "Withdrawal to $upiId",
                amountString = "- ₹${String.format("%.2f", rupeesAmount)}",
                isCredit = false,
                timestamp = "Just Now"
            )
        )
        return true
    }

    suspend fun markNotificationsRead(userPhone: String) {
        dao.markAllNotificationsAsReadForUser(userPhone)
    }

    // --- ADMIN & DEPOSIT SYSTEM ---

    suspend fun submitDepositRequest(userPhone: String, amount: Double, utrNumber: String) {
        val currentProfile = dao.getUserByPhoneDirect(userPhone) ?: UserProfileEntity(phoneNumber = userPhone)
        val request = DepositRequestEntity(
            userPhoneNumber = userPhone,
            userName = currentProfile.ign,
            ffUid = currentProfile.ffUid,
            amount = amount,
            utrNumber = utrNumber,
            status = "PENDING",
            timestamp = "Just Now"
        )
        dao.insertDepositRequest(request)

        val notif = NotificationEntity(
            userPhoneNumber = userPhone,
            title = "Deposit Request Submitted",
            message = "Your deposit of ₹${String.format("%.2f", amount)} (UTR: $utrNumber) is pending Admin approval.",
            timeAgo = "Just Now"
        )
        dao.insertNotifications(listOf(notif))
    }

    suspend fun approveDepositRequest(request: DepositRequestEntity) {
        dao.updateDepositRequest(request.copy(status = "APPROVED"))

        val userPhone = request.userPhoneNumber
        val currentProfile = dao.getUserByPhoneDirect(userPhone)
        if (currentProfile != null) {
            val bonusDiamonds = ((request.amount / 100) * 10).toInt()
            dao.insertOrUpdateProfile(
                currentProfile.copy(
                    rupeesBalance = currentProfile.rupeesBalance + request.amount,
                    diamondsBalance = currentProfile.diamondsBalance + bonusDiamonds
                )
            )

            dao.insertTransaction(
                TransactionEntity(
                    userPhoneNumber = userPhone,
                    type = "DEPOSIT",
                    title = "Approved Deposit (UTR: ${request.utrNumber})",
                    amountString = "+ ₹${String.format("%.2f", request.amount)}",
                    isCredit = true,
                    timestamp = "Just Now"
                )
            )

            dao.insertNotifications(
                listOf(
                    NotificationEntity(
                        userPhoneNumber = userPhone,
                        title = "Deposit Approved! 🎉",
                        message = "₹${String.format("%.2f", request.amount)} + $bonusDiamonds Bonus Diamonds credited to your wallet balance.",
                        timeAgo = "Just Now"
                    )
                )
            )
        }
    }

    suspend fun rejectDepositRequest(request: DepositRequestEntity) {
        dao.updateDepositRequest(request.copy(status = "REJECTED"))

        dao.insertNotifications(
            listOf(
                NotificationEntity(
                    userPhoneNumber = request.userPhoneNumber,
                    title = "Deposit Request Declined",
                    message = "Deposit of ₹${String.format("%.2f", request.amount)} (UTR: ${request.utrNumber}) was rejected by Admin.",
                    timeAgo = "Just Now"
                )
            )
        )
    }

    suspend fun createTournament(tournament: TournamentEntity) {
        dao.insertTournament(tournament)

        dao.insertNotifications(
            listOf(
                NotificationEntity(
                    title = "New Tournament Announced!",
                    message = "${tournament.title} (${tournament.format}) is now open for registration! Prize Pool: ₹${tournament.prizePool.toInt()}",
                    timeAgo = "Just Now"
                )
            )
        )
    }

    suspend fun updateRoomCredentials(tournamentId: String, roomId: String, roomPassword: String) {
        val tournamentsList = dao.getAllTournaments().firstOrNull() ?: emptyList()
        val existing = tournamentsList.find { it.id == tournamentId }
        if (existing != null) {
            val updated = existing.copy(roomId = roomId, roomPassword = roomPassword, status = "LIVE")
            dao.updateTournament(updated)
            dao.updateJoinedMatchRoom(tournamentId, roomId, roomPassword)

            dao.insertNotifications(
                listOf(
                    NotificationEntity(
                        title = "Room Credentials Updated!",
                        message = "Room ID: $roomId | Pass: $roomPassword for '${existing.title}' is released.",
                        timeAgo = "Just Now"
                    )
                )
            )
        }
    }
}
