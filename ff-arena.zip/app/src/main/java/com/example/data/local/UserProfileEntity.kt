package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val phoneNumber: String = "9876543210",
    val ign: String = "SK_GAMER_99",
    val ffUid: String = "8274910283",
    val rupeesBalance: Double = 250.0,
    val diamondsBalance: Int = 120,
    val matchesPlayed: Int = 42,
    val totalKills: Int = 188,
    val totalEarnings: Double = 4850.0,
    val createdAt: Long = System.currentTimeMillis()
)
