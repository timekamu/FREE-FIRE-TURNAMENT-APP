package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "joined_matches")
data class JoinedMatchEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userPhoneNumber: String = "",
    val tournamentId: String,
    val title: String,
    val format: String,
    val ign: String,
    val ffUid: String,
    val entryFeePaid: Int,
    val prizePool: Double,
    val dateTimeString: String,
    val status: String, // JOINED, COMPLETED
    val roomId: String,
    val roomPassword: String,
    val userKills: Int = 0,
    val userPosition: String = "",
    val winningsEarned: Double = 0.0,
    val joinedAtTimestamp: Long = System.currentTimeMillis()
)
