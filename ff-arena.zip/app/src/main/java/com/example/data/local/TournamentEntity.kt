package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tournaments")
data class TournamentEntity(
    @PrimaryKey val id: String,
    val title: String,
    val format: String, // Squad, Solo, Duo
    val entryFeeDiamonds: Int,
    val entryFeeRupees: Double = 10.0,
    val prizePool: Double,
    val filledSlots: Int,
    val maxSlots: Int,
    val status: String, // LIVE, UPCOMING, COMPLETED
    val dateTimeString: String,
    val mapName: String,
    val roomId: String,
    val roomPassword: String
)
