package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userPhoneNumber: String = "",
    val type: String, // DEPOSIT, MATCH_FEE, WINNING, WITHDRAWAL
    val title: String,
    val amountString: String,
    val isCredit: Boolean,
    val timestamp: String
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userPhoneNumber: String = "",
    val title: String,
    val message: String,
    val timeAgo: String,
    val isRead: Boolean = false
)
