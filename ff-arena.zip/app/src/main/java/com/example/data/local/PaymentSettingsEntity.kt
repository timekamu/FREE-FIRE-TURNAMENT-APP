package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "payment_settings")
data class PaymentSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val qrImageUrl: String = "",
    val upiOrNumber: String = "9876543210@upi",
    val instructions: String = "Scan QR Code or send payment to the UPI ID / Number. After payment, submit the 12-digit UTR / Reference number below for approval."
)
