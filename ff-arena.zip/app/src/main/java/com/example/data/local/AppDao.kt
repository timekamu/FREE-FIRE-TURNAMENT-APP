package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // User Profile
    @Query("SELECT * FROM user_profile WHERE phoneNumber = :phoneNumber")
    fun getUserProfileByPhone(phoneNumber: String): Flow<UserProfileEntity?>

    @Query("SELECT * FROM user_profile WHERE phoneNumber = :phoneNumber LIMIT 1")
    suspend fun getUserByPhoneDirect(phoneNumber: String): UserProfileEntity?

    @Query("SELECT * FROM user_profile ORDER BY createdAt DESC")
    fun getAllUsers(): Flow<List<UserProfileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProfile(profile: UserProfileEntity)

    // Tournaments
    @Query("SELECT * FROM tournaments")
    fun getAllTournaments(): Flow<List<TournamentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTournaments(tournaments: List<TournamentEntity>)

    @Query("SELECT * FROM tournaments WHERE id = :id LIMIT 1")
    suspend fun getTournamentById(id: String): TournamentEntity?

    @Update
    suspend fun updateTournament(tournament: TournamentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTournament(tournament: TournamentEntity)

    // Joined Matches
    @Query("SELECT * FROM joined_matches WHERE userPhoneNumber = :phoneNumber OR userPhoneNumber = '' ORDER BY joinedAtTimestamp DESC")
    fun getJoinedMatchesForUser(phoneNumber: String): Flow<List<JoinedMatchEntity>>

    @Query("SELECT * FROM joined_matches ORDER BY joinedAtTimestamp DESC")
    fun getJoinedMatches(): Flow<List<JoinedMatchEntity>>

    @Query("SELECT * FROM joined_matches WHERE tournamentId = :tournamentId")
    suspend fun getJoinedMatchesForTournamentDirect(tournamentId: String): List<JoinedMatchEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJoinedMatch(joinedMatch: JoinedMatchEntity)

    @Query("UPDATE joined_matches SET roomId = :roomId, roomPassword = :roomPassword WHERE tournamentId = :tournamentId")
    suspend fun updateJoinedMatchRoom(tournamentId: String, roomId: String, roomPassword: String)

    @Query("UPDATE joined_matches SET status = :status WHERE tournamentId = :tournamentId")
    suspend fun updateJoinedMatchesStatus(tournamentId: String, status: String)

    // Payment Settings
    @Query("SELECT * FROM payment_settings WHERE id = 1")
    fun getPaymentSettings(): Flow<PaymentSettingsEntity?>

    @Query("SELECT * FROM payment_settings WHERE id = 1 LIMIT 1")
    suspend fun getPaymentSettingsDirect(): PaymentSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdatePaymentSettings(settings: PaymentSettingsEntity)

    // Deposit Requests
    @Query("SELECT * FROM deposit_requests ORDER BY id DESC")
    fun getDepositRequests(): Flow<List<DepositRequestEntity>>

    @Query("SELECT * FROM deposit_requests WHERE userPhoneNumber = :phoneNumber ORDER BY id DESC")
    fun getDepositRequestsForUser(phoneNumber: String): Flow<List<DepositRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDepositRequest(request: DepositRequestEntity)

    @Update
    suspend fun updateDepositRequest(request: DepositRequestEntity)

    // Transactions
    @Query("SELECT * FROM transactions WHERE userPhoneNumber = :phoneNumber OR userPhoneNumber = '' ORDER BY id DESC")
    fun getTransactionsForUser(phoneNumber: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions ORDER BY id DESC")
    fun getTransactions(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(transactions: List<TransactionEntity>)

    // Notifications
    @Query("SELECT * FROM notifications WHERE userPhoneNumber = :phoneNumber OR userPhoneNumber = '' ORDER BY id DESC")
    fun getNotificationsForUser(phoneNumber: String): Flow<List<NotificationEntity>>

    @Query("SELECT * FROM notifications ORDER BY id DESC")
    fun getNotifications(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<NotificationEntity>)

    @Query("UPDATE notifications SET isRead = 1 WHERE userPhoneNumber = :phoneNumber OR userPhoneNumber = ''")
    suspend fun markAllNotificationsAsReadForUser(phoneNumber: String)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllNotificationsAsRead()
}
