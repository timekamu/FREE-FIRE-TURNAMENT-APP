package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "deposit_requests")
data class DepositRequestEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userPhoneNumber: String = "",
    val userName: String = "",
    val ffUid: String = "",
    val amount: Double = 0.0,
    val utrNumber: String = "",
    val status: String = "PENDING", // PENDING, APPROVED, REJECTED
    val timestamp: String = "Just Now"
)
